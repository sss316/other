
#include "AesCipher.h"


int main(int argc, const char * argv[])
{
//    {
//        size_t length;
//        unsigned char* pBuffer = AesCipher::readFromFile(length, "/Users/suguanghui/work/test.png");
//        AesCipher crypto;
//        crypto.makeRoundKey("this is a key.oo");
//        crypto.setIV("chain.0123456789");
//        crypto.encryptString(pBuffer,length, AesCipher::CBC);
//        AesCipher::writeToFile(pBuffer, length, "/Users/suguanghui/work/test1.png");
//        delete [] pBuffer;
//    }
//    {
//        size_t length;
//        unsigned char* pBuffer = AesCipher::readFromFile(length, "/Users/suguanghui/work/test1.png");
//        AesCipher crypto;
//        crypto.makeRoundKey("this is a key.oo");
//        crypto.setIV("chain.0123456789");
//        crypto.decryptString(pBuffer,length, AesCipher::CBC);
//        AesCipher::writeToFile(pBuffer, length, "/Users/suguanghui/work/test2.png");
//        delete [] pBuffer;
//    }
    
    AesCipher::List("/Users/suguanghui/work/cocos2d-x-2.2.3 aes/projects/Havoc/Resources","/Users/suguanghui/work/123ex");
    return 0;
}

