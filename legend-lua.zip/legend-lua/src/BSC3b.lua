--data
cc.exports.C3bData={
    qtds = {
        stand={0,8,0.278},
        walk={11,15,(15-11)/30/0.6},
        attack={193,206,(206-193)/30/0.3},
        specialattack1={160,220,0.3},
        defend={92,96,0.7},
        knocked={254,260,0.7},
        dead={49,54,(54-49)/30/3},
    },
    tsgz = {
        stand={0,4,0.278},
        walk={51,55,(55-51)/30/0.6},
        attack={56,66,(66-56)/30/0.3},
        dead={43,46,(46-43)/30/3},
    },
    nmw = {
        stand={0,7,0.278},
        walk={31,35,4/30/0.6},
        attack={301,319,20/30/0.3},
        dead={62,67,5/30/3},
    },
    yd = {
        stand={0,6,0.278},
        walk={20,24,4/30/0.6},
        attack={79,86,7/30/0.3},
        dead={60,69,9/30/3},
    },
    yj = {
        stand={0,6,0.278},
        walk={50,66,16/30/0.6},
        attack={316,331,15/30/0.3},
        dead={320,346,26/30/3},
    },
    jwh = {
        stand={121,127,0.278},
        walk={59,63,4/30/0.6},
        attack={301,331,30/30/0.3},
        dead={46,52,6/30/3},
    },
}

--dispose -1, -1 mean play over.
for k,v in pairs(C3bData) do
    for m,n in pairs(v) do
        if n[2]==-1 then
            local animation = cc.Animation3D:create(k..".c3b")
            if animation then n[2]= animation:getDuration()*30 end
        end
    end
end

--play call by user. --animate:getSpeed(),animate:getDuration(),animate:getElapsed()
function C3bData.play(sprite3d,actionName)
    if actionName==sprite3d._actionName then return end
    sprite3d._actionName = actionName
    local name = sprite3d._name
    local animate = cc.Animate3D:createWithFrames(cc.Animation3D:create(name..".c3b"),C3bData[name][actionName][1],C3bData[name][actionName][2])
    animate:setQuality(2)  --Animate3DQuality.QUALITY_HIGH
    animate:setSpeed(C3bData[name][actionName][3])
    sprite3d:stopAllActions()
    if sprite3d._callBack then
        sprite3d:runAction(cc.RepeatForever:create(cc.Sequence:create(animate,cc.CallFunc:create(sprite3d._callBack))))
    else
        sprite3d:runAction(cc.RepeatForever:create(animate))
    end
end

