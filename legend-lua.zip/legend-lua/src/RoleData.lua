--map infomation.
cc.exports.MapData={
    maya={
        name = "玛雅大陆",
        file = "model/scene/changing.c3b",
        size = cc.size(50,50),
        offset = cc.p(1600,-1550),
        collision = {{6,5},{7,5},{8,5},{9,5},{6,6},{7,6},{8,6},{9,6},{6,7},{7,7},{8,7},{9,7},{6,8},{7,8},{8,8},{9,8},},
        monster = {
            --hero type,level,count,time aliquot by this,(x,y position).
            {EHero.fighter,1,1,60,10,3},
            {EHero.archmage,1,1,60,10,1},
            {EHero.redEvilBoar,1,1,60},
            {EHero.DarkLord,1,1,300,15,12},
            {EHero.leftProtector,1,1,60,13,12},
            {EHero.rightProtector,1,1,60,17,12},
        },
    },
}
cc.exports.RoleData={
    fighter = {
        name="战士",
        hp=675,
        hpAdd=20,
        defense=5,
        defenseAdd=1,
        hurt=55,
        hurtAdd=2,
        exp=100,
        expAdd=50,
        deadExp=100,
        restore=1,
        restoreAdd=1,
        model = "qtds",
    },
    archmage = {
        name="法师",
        hp=220,
        hpAdd=20,
        defense=50,
        defenseAdd=1,
        hurt=40,
        hurtAdd=2,
        exp=1000,
        expAdd=100,
        deadExp=100,
        restore=10,
        restoreAdd=1,
        model = "tsgz",
    },
    redEvilBoar = {
        name="红野猪",
        hp=300,
        hpAdd=20,
        defense=1,
        defenseAdd=1,
        hurt=10,
        hurtAdd=2,
        exp=1000,
        expAdd=100,
        deadExp=100,
        restore=1,
        restoreAdd=1,
        model = "nmw",
    },
    DarkLord = {
        name="圣地魔王",
        hp=32000,
        hpAdd=20,
        defense=100,
        defenseAdd=1,
        hurt=500,
        hurtAdd=2,
        exp=1000,
        expAdd=100,
        deadExp=1000,
        restore=100,
        restoreAdd=1,
        model = "yd",
    },
    leftProtector = {
        name="左护法",
        hp=1000,
        hpAdd=20,
        defense=10,
        defenseAdd=1,
        hurt=100,
        hurtAdd=2,
        exp=1000,
        expAdd=100,
        deadExp=1000,
        restore=100,
        restoreAdd=1,
        model = "yj",
    },
    rightProtector = {
        name="右护法",
        hp=1000,
        hpAdd=20,
        defense=10,
        defenseAdd=1,
        hurt=100,
        hurtAdd=2,
        exp=1000,
        expAdd=100,
        deadExp=1000,
        restore=100,
        restoreAdd=1,
        model = "jwh",
    },
    taoist = {
        name="道士",
        hp=400,
        hpAdd=20,
        defense=50,
        defenseAdd=1,
        hurt=40,
        hurtAdd=2,
        exp=1000,
        expAdd=100,
        deadExp=0,
        restore=1,
        restoreAdd=1,
        model = "jwh",
    },
}

cc.exports.SkillData = {
    fighter = {
        {"战神血统","永久增加战士的防御和回血速度",2,4,6,8,2,4,6,8},
        {"麒麟臂","永久增加战士暴击率，暴击值",0.05,0.1,0.15,0.2,0.2,0.4,0.6,0.8},
        {"刀刀刺杀","对刀尖处的敌人无视大量防御",8,16,24,32},
        {"烈火爆击","每隔10s战士会100%对第一格的敌人暴击，暴击值附加1,2,3,4",1,2,3,4,4},
    },
    archmage = {
        {"冰雹","范围3*3内敌方单位溅射",0.2,0.4,0.6,0.8},
        {"冰刺","法师攻击后的地上留下9个碎片，持续一段时间，并对走过的敌人造成伤害",0.05,0.1,0.15,0.2,0.2,0.4,0.6,0.8},
        {"魔法盾","增加防御4,8,12,16，持续6,7,8,9",4,8,12,16,6,7,8,9,10},
        {"法力无边","增加法师的回血速度",4,8,12,16},
    },
}

function RoleData:init(role)
    local lfrom2 = role._level-1
    local data = self[UserInfo:heroName(role._hero)]
    role._totalHp=data.hp+data.hpAdd*lfrom2
    role._hp=role._totalHp
    role._defense=data.defense+data.defenseAdd*lfrom2
    role._hurt=data.hurt+data.hurtAdd*lfrom2
    role._totalExp=data.exp+data.expAdd*lfrom2
    role._deadExp=data.deadExp
    role._restore=data.restore+data.restoreAdd*lfrom2
    role._model = data.model
    role._state=ERoleState.idle
    role._critRate=0
    role._critValue=1
    if role._name==nil then
        role._name=data.name
        role._camp=ECamp.monster
        role._exp=0
        
    end
    --weapon property and so on.


    --skill property.
    if role._camp~=ECamp.monster then
        for i=1, 4 do
            Skill:upLevel(role,i,true)
        end
    end
end

--player add experience, upgrade propebly.
function RoleData:addExp(role,exp)
    local upGrade = false
    role._exp = role._exp+exp
    while role._exp>=role._totalExp do
        role._exp=role._exp-role._totalExp
        role._level = role._level+1
        
        --property change.
        local data = self[UserInfo:heroName(role._hero)]
        role._totalHp=role._totalHp+data.hpAdd
        role._hp=role._totalHp
        role._defense=role._defense+data.defenseAdd
        role._hurt=role._hurt+data.hurtAdd
        role._totalExp=role._totalExp+data.expAdd
        role._restore=role._restore+data.restoreAdd
        
        upGrade = true
    end
    return upGrade
end
