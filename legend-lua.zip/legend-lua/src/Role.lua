cc.exports.Role = class("Role",function()return cc.Node:create()end)


function Role:gotoRelife()
    if UserInfo._player==self or _UIBattleLayer._locked==self then
        _UIBattleLayer._locked=nil
    end
    self:stand()
    self._hp = self._totalHp
    self._location = {x=UserInfo._bornLocation.x,y=UserInfo._bornLocation.y}
	local destPoint = LuaUtils:pMult(self._location,UserInfo._tileSize)
    self:setPosition3D(cc.vec3(destPoint.x,0,-destPoint.y))
    self._hpTimer:setPercentage(100)
    self._hpNum:setString(math.floor(self._hp).."/"..self._totalHp.." v:"..self._level)
    self._hpBack:setVisible(true)
    table.insert(_GameLayer._roleArray,self)
end

function cc.exports.spriteCallBack(sender)
    local pself = sender._role
    if pself._state==ERoleState.walk then
        pself:idle()
    elseif pself._state==ERoleState.attack then
        C3bData.play(pself._sprite,"stand")
    elseif pself._state==ERoleState.dead then
        sender:stopAllActions()
    end
end

function cc.exports.spriteCallBackByServer(sender)
    local pself = sender._role
    if pself._state==ERoleState.dead then
        sender:stopAllActions()
        pself:runAction(cc.Sequence:create(cc.MoveBy:create(1,cc.vec3(0,-100,0)),cc.RemoveSelf:create()))
    else
        C3bData.play(pself._sprite,"stand")
    end
end

function Role:init(roleTable)
    LuaUtils:tableCopy(self,roleTable)
    RoleData:init(self)
    if self._rid==UserInfo._rid then UserInfo._player = self end
    local destPoint = LuaUtils:pMult(self._location,UserInfo._tileSize)
    self:setPosition3D(cc.vec3(destPoint.x,0,-destPoint.y))

    
    self._sprite = cc.Sprite3D:create(self._model..".c3b")
    self:addChild(self._sprite,100)
    self._sprite._name = self._model
    self._sprite._callBack = UserInfo._player==self and spriteCallBack or spriteCallBackByServer
    self._sprite._role = self
    self._sprite:setPosition3D(cc.vec3(0,0,0))
    self._sprite:setRotation3D(cc.vec3(0,-90,0))
    C3bData.play(self._sprite,"stand")
    
    local sp = cc.Sprite3D:create("axe.c3b")
    sp:setScale(5)
    
    local hand = self._sprite:getAttachNode("Bip001 R Hand")
    if hand==nil then hand = self._sprite:getAttachNode("Bip002 R Hand") end
    if hand==nil then hand = self._sprite:getAttachNode("Bip003 R Hand") end
    hand:addChild(sp)
    
    local count = self._sprite:getMeshCount()
    for i=1,count do
        local mesh = self._sprite:getMeshByIndex(i-1)
        if string.find(mesh:getName(),"wq") then
            mesh:setVisible(false)
        end
    end
    
    local hpBack = cc.Sprite:createWithSpriteFrameName("hp.png")
    hpBack:setRotation3D(cc.vec3(-45,0,0))
    hpBack:setPosition3D(cc.vec3(0,80,0))
    hpBack:setColor(cc.c3b(0,0,0))
    hpBack:setScaleY(2)
    self:addChild(hpBack)
    self._hpBack = hpBack
    if UserInfo._player ~= self then
    	hpBack:setVisible(false)
    end
    
    local hpTimer = cc.ProgressTimer:create(cc.Sprite:createWithSpriteFrameName("hp.png"))
    hpTimer:setType(cc.PROGRESS_TIMER_TYPE_BAR)
    hpTimer:setMidpoint(cc.p(0, 0))
    hpTimer:setBarChangeRate(cc.p(1, 0))
    hpBack:addChild(hpTimer)
    hpTimer:setNormalizedPosition(cc.p(0.5,0.5))
    hpTimer:setPercentage(100)
    self._hpTimer = hpTimer
    
    local ttfconfig = {outlineSize=1,fontSize=10,fontFilePath="Arial.ttf"}
    local hpNum = cc.Label:createWithTTF(ttfconfig,self._hp.."/"..self._totalHp.." v:"..self._level)
    hpNum:enableOutline(cc.c4b(0,0,0,255))
--    hpNum:enableGlow(cc.c4b(255, 255, 0, 255))
    hpNum:setColor(cc.c3b(255,255,255))
    hpBack:addChild(hpNum)
    hpNum:setNormalizedPosition(cc.p(0.5,2.2))
    hpNum:setScaleY(1/2)
    self._hpNum = hpNum
    

    local nameLabel = cc.Label:createWithSystemFont(self._name,"Arial.ttf",12)
    nameLabel:setColor(cc.c3b(255,255,255))
    self:addChild(nameLabel)
    nameLabel:setRotation3D(cc.vec3(-45,0,0))
    nameLabel:setPosition3D(cc.vec3(0,120,0))
end

function Role:idle()
    self._state=ERoleState.idle
    LuaUtils:tagAction(self,cc.Sequence:create(cc.DelayTime:create(0.02),cc.CallFunc:create(self.stand)),ETagType.idleToStand)
end

function Role:stand()
    self._state = ERoleState.stand
    C3bData.play(self._sprite,"stand")
end


function Role:walk(offset)
    if self._state~=ERoleState.idle and self._state~=ERoleState.stand then return end
    offset = UserInfo:getOffsetWithColloison(self,offset)
    if offset==nil then return end
    
    self._state = ERoleState.walk
    self:stopActionByTag(ETagType.idleToStand)
    self._location = cc.pAdd(self._location,offset)
    local destPoint = LuaUtils:pMult(self._location,UserInfo._tileSize)
    self:runAction(cc.MoveTo:create(0.6,cc.vec3(destPoint.x,0,-destPoint.y)))
    local radius = self._sprite:getRotation3D()
    self._sprite:setRotation3D(cc.vec3(radius.x,math.deg(cc.pToAngleSelf(offset)),radius.z))
    C3bData.play(self._sprite,"walk")

    --send to server.
    if self._rid==UserInfo._rid then
        local actionTable={
            action=ESendType.move,
            rid=UserInfo._rid,
            pos=self._location
        }
        BSSocket:send(json.encode(actionTable).."\n")
    end
end

function Role:attack(epos)
    if self._state~=ERoleState.idle and self._state~=ERoleState.stand then return end
    cc.SimpleAudioEngine:getInstance():playEffect("music/hit.mp3",false)
    --overlap position dispose.
    if LuaUtils:pEqual(epos,self._location) then
        epos=cc.p(epos.x,epos.y-1)
    end
    self._state = ERoleState.attack
    self:stopActionByTag(ETagType.idleToStand)
    local radius = self._sprite:getRotation3D()
    local offset = UserInfo:getV(cc.pSub(epos,self._location))
    self._sprite:setRotation3D(cc.vec3(radius.x,math.deg(cc.pToAngleSelf(offset)),radius.z))
    C3bData.play(self._sprite,"attack")
    --end attacked,play stand animation,and delay 1.5s change state to idle
    LuaUtils:tagAction(self,
        cc.Sequence:create(cc.DelayTime:create(0.3),cc.CallFunc:create(self.idle)),
        ETagType.attackToIdle)
        
    --send to server.
    if self._rid==UserInfo._rid then
        local actionTable={
            action=ESendType.attack,
            rid=self._rid,
            hitPos={x=epos.x,y=epos.y}
        }
        BSSocket:send(json.encode(actionTable).."\n")
    end
end

function Role:dropHP(hp)
    Skill:addMagicShield(self)
    local critleAttack = cc.Sprite:createWithSpriteFrameName("hpexplosion.png")
    critleAttack:setRotation3D(cc.vec3(0,0,0))
    self:addChild(critleAttack)
    critleAttack:setPosition3D(cc.vec3(0,80,0))
    critleAttack:setCameraMask(2)
    critleAttack:setScale(0.2)
    critleAttack:setVisible(false)
    critleAttack:runAction(cc.Sequence:create(cc.DelayTime:create(0.2),
        cc.Show:create(),
        cc.MoveBy:create(1,cc.vec3(0,50,0)),
        cc.FadeOut:create(0.5),
        cc.RemoveSelf:create()))


    local ttfconfig = {outlineSize=1,fontSize=12,fontFilePath="Arial.ttf"}
    local blood = cc.Label:createWithTTF(ttfconfig,"-"..math.floor(self._hp-hp))
    blood:enableOutline(cc.c4b(0,0,0,255))
    blood:setColor(cc.c3b(255,0,0))
    critleAttack:addChild(blood)
    blood:setNormalizedPosition(cc.p(0.5,0.5))
    blood:setCameraMask(2)
    blood:setScale(5)

    
    self._hp=hp
    self._hpTimer:setPercentage(100*self._hp/self._totalHp)
    self._hpNum:setString(math.floor(self._hp).."/"..self._totalHp.." v:"..self._level)
    if hp<=0 then
        self._hpBack:stopAllActions()
        self._hpBack:setVisible(false)
        if UserInfo._player==self or _UIBattleLayer._locked==self then
            _UIBattleLayer._locked=nil
        end
        
        local pos = 1
        for k, v in pairs(_GameLayer._roleArray) do
            if v==self then
                pos = k
            end
        end
        table.remove(_GameLayer._roleArray,pos)
        self:dead()
    else
        if UserInfo._player ~= self then
            self._hpBack:stopAllActions()
            self._hpBack:setVisible(true)
            self._hpBack:runAction(cc.Sequence:create(cc.DelayTime:create(10),cc.Hide:create()))
        end
    end
end

function Role:dead()
    Skill:removeMagicShield({self})
    Skill:setMagicShieldReady({self})
    self:stopActionByTag(ETagType.idleToStand)
    self:stopActionByTag(ETagType.attackToIdle)
	self._state=ERoleState.dead
    C3bData.play(self._sprite,"dead")
    if self._camp~=ECamp.monster then
        --5 is relife time
        self:runAction(cc.Sequence:create(cc.DelayTime:create(5),
            cc.CallFunc:create(self.gotoRelife)
        ))
    end
end


function Role:attackByServer(epos)
    cc.SimpleAudioEngine:getInstance():playEffect("music/hit2.mp3",false)
    local radius = self._sprite:getRotation3D()
    local offset = UserInfo:getV(cc.pSub(epos,self._location))
    self._sprite:setRotation3D(cc.vec3(radius.x,math.deg(cc.pToAngleSelf(offset)),radius.z))
    C3bData.play(self._sprite,"attack")
end

function Role:walkByServer(offset)
    self._location = cc.pAdd(self._location,offset)
    local destPoint = LuaUtils:pMult(self._location,UserInfo._tileSize)
    self:runAction(cc.MoveTo:create(0.6,cc.vec3(destPoint.x,0,-destPoint.y)))
    local radius = self._sprite:getRotation3D()
    self._sprite:setRotation3D(cc.vec3(radius.x,math.deg(cc.pToAngleSelf(offset)),radius.z))
    C3bData.play(self._sprite,"walk")
end

