cc.exports.EHero =
    {
        fighter = 1,
        archmage = 2,
        taoist = 3,
        DarkLord = 4,
        leftProtector = 5,
        rightProtector = 6,
        redEvilBoar = 7,
    }
cc.exports.ECamp =
    {
        liuxing = 1,
        hudie = 2,
        monster = 3,
    }
cc.exports.ESendType =
    {
        attack = 1,
        move = 2,
        svhp = 3,
        svattack = 4,
        svwalk = 5,
        svmonster = 6,
        upSkill = 7,
        svExp =8,
    }
cc.exports.ETagType =
    {
        idleToStand = 1001,
        attackToIdle = 1002,
    }
cc.exports.ERoleState =
    {
        idle = 1,
        stand = 2,
        attack = 3,
        walk = 4,
        dead = 5,
    }
    
--player data.
cc.exports.UserInfo={
    _rid=100000,
    _level=1,
    _name="红军小战士",
    _camp=ECamp.liuxing,
    _hero=EHero.archmage,
    _exp=0,
    _player = nil,
    _tileSize = cc.p(60,60),
    _map = "maya",
    _skillLevel = {0,0,0,0},
    _skillPointCount = 1,
    _bornLocation = cc.p(2,2),
}

--camp enum to string.
function UserInfo:campName(camp)
    local switch = {}
    switch[ECamp.liuxing] = function()return "流星" end
    switch[ECamp.hudie] = function()return "蝴蝶" end
    switch[ECamp.monster] = function()return "怪物" end
    return switch[camp]()
end

--camp enum to string.
function UserInfo:heroName(hero)
    local switch={}
    switch[EHero.fighter] = function()return "fighter" end
    switch[EHero.archmage] = function()return "archmage" end
    switch[EHero.taoist] = function()return "taoist" end
    switch[EHero.redEvilBoar] = function()return "redEvilBoar" end
    switch[EHero.leftProtector] = function()return "leftProtector" end
    switch[EHero.rightProtector] = function()return "rightProtector" end
    switch[EHero.DarkLord] = function()return "DarkLord" end
    return switch[hero]()
end

--get a vector's direction(8,left,right,up,down....).
function UserInfo:getV(pos)
    local offset = {x=0,y=0}
    if pos.x<-0.01 then offset.x=-1 end
    if pos.x>0.01 then offset.x=1 end
    if pos.y<-0.01 then offset.y=-1 end
    if pos.y>0.01 then offset.y=1 end
    return offset
end

--get every one attack rangle..
function UserInfo:getAttackRange(role1,role2)
    local myLocation=role1._location
    local enemyLocation=role2._location
    local x=math.abs(enemyLocation.x-myLocation.x)
    local y=math.abs(enemyLocation.y-myLocation.y)
    if role1._hero==EHero.fighter then
        if x<=2 and y<=2 and x+y~=3 then
            return true
        end
    elseif role1._hero==EHero.archmage or role1._hero==EHero.taoist then
        if cc.pGetDistance(myLocation,enemyLocation)<=4 then
            return true
        end
    else
        if x<=1 and y<=1 then
            return true
        end
    end
    return false
end

--is or not hit in enemy.
function UserInfo:hitEnemy(role,hitPos,ePos)
    if role._hero==EHero.fighter then
        local offset = UserInfo:getV(cc.pSub(hitPos,role._location))
        local p1 = cc.pAdd(role._location,offset)
        if LuaUtils:pEqual(cc.pAdd(p1,offset),ePos) then
        	return 2
        elseif LuaUtils:pEqual(role._location,ePos) or LuaUtils:pEqual(p1,ePos) then
            return 1
        end
    elseif role._hero==EHero.archmage then
        local x=math.abs(ePos.x-hitPos.x)
        local y=math.abs(ePos.y-hitPos.y)
        if x<=0.01 and y<=0.01 then
        	return 2
        elseif x<=1 and y<=1 then
            return 1
        end
    elseif role._hero==EHero.taoist then
        local x=math.abs(ePos.x-hitPos.x)
        local y=math.abs(ePos.y-hitPos.y)
        if x==0 and y==0 then
            return 1
        end
    else
        local offset = UserInfo:getV(cc.pSub(hitPos,role._location))
        if LuaUtils:pEqual(role._location,ePos) or LuaUtils:pEqual(cc.pAdd(role._location,offset),ePos) then
            return 1
        end
    end
    return 0
end

--player is collision with tile or wall.
function UserInfo:isCollision(location)
    local rect = cc.rect(1,1,MapData[self._map].size.width,MapData[self._map].size.height)
    if cc.rectContainsPoint(rect,location)==false then
    	return true
    end
    local collision = MapData[self._map].collision
    for k,v in pairs(collision) do
        if LuaUtils:pEqual(cc.p(v[1],v[2]),location) then
            return true
        end
    end
    return false
end

--get an moveable place.let monster born and relife.
function UserInfo:getStandLocation()
    local w=MapData[self._map].size.width
    local h=MapData[self._map].size.height
    local location = nil
	repeat
        location = cc.p(math.random(1,w),math.random(1,h))
    until self:isCollision(location)==false
    return location
end


--get true vector for player.
function UserInfo:getOffsetWithColloison(role,offset)
    local points={cc.p(1,0),cc.p(1,1),cc.p(0,1),cc.p(-1,1),cc.p(-1,0),cc.p(-1,-1),cc.p(0,-1),cc.p(1,-1)}
    local index = 0
    for i=1,8 do
        if LuaUtils:pEqual(points[i],offset) then
            index=i
            break
        end
    end
    local bCollision=true
    local randNum=math.random()>0.5 and 1 or -1

    for i=1, 8 do
        if self:isCollision(cc.pAdd(role._location,points[index]))==false then
            if role._camp~=ECamp.monster then
                bCollision=false
                break
            elseif LocalServer:roleInLocation(cc.pAdd(role._location,points[index]))==nil then
                bCollision=false
                break
            end
        end
        index=index+i*randNum
        randNum=-randNum
        if index>8 then
            index = index-8
        elseif index<1 then
            index = index+8
        end
    end
    if bCollision then return nil end
    return points[index]
end

