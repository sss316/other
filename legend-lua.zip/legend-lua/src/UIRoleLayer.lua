cc.exports.UIRoleLayer = class("UIRoleLayer",function()
    return cc.Layer:create()
end)

function UIRoleLayer:scene()
    local scene = cc.Scene:create()
    scene:addChild(UIRoleLayer.new())
    return scene
end

function UIRoleLayer:ctor()
    UserInfo._type="fighter"

    local size = cc.Director:getInstance():getWinSize()
    local bg = cc.Sprite:create("door.png")
    bg:setPosition(size.width/2,size.height/2)
    self:addChild(bg)
    bg:setScale(2)
    self._bg=bg

    local menuBack = cc.MenuItemImage:create("button.png", "button2.png")
    LuaUtils.BSMenuAdd(self,menuBack,BSLocalizedString("back"))
    menuBack:setPosition(cc.p(size.width-100, size.height-50))
    menuBack:registerScriptTapHandler(function()
        cc.Director:getInstance():replaceScene(UIMainLayer:scene())
    end)
    
    local spriteFighter = cc.Sprite3D:create("qtds.c3b")
    spriteFighter._name="qtds"
    spriteFighter:setPosition(cc.p(120, 270))
    self:addChild(spriteFighter,100)
    spriteFighter:setScale(1.2)
    spriteFighter:setRotation3D(cc.vec3(0,-90,0))
    C3bData.play(spriteFighter,"stand")
    spriteFighter:setGlobalZOrder(10)
    
    
    local spriteMagician = cc.Sprite3D:create("qtds.c3b")
    spriteMagician._name="qtds"
    spriteMagician:setPosition(cc.p(360, 270))
    self:addChild(spriteMagician,100)
    spriteMagician:setScale(1.2)
    spriteMagician:setRotation3D(cc.vec3(0,-90,0))
    C3bData.play(spriteMagician,"stand")
    spriteMagician:setGlobalZOrder(10)
    
    local menuFighter = cc.MenuItemImage:create("button.png", "button2.png")
    LuaUtils.BSMenuAdd(self,menuFighter,BSLocalizedString("fighter"))
    menuFighter:setPosition(cc.p(120, 220))
    menuFighter:registerScriptTapHandler(function()
        if UserInfo._type~="fighter" then
            UserInfo._type="fighter"
        end
    end)
    


    local menuMagician = cc.MenuItemImage:create("button.png", "button2.png")
    LuaUtils.BSMenuAdd(self,menuMagician,BSLocalizedString("magician"))
    menuMagician:setPosition(cc.p(360, 220))
    menuMagician:registerScriptTapHandler(function()
        if UserInfo._type~="magician" then
            UserInfo._type="magician"
            end
    end)
    
    local menuLiuxing = cc.MenuItemImage:create("button.png", "button2.png")
    LuaUtils.BSMenuAdd(self,menuLiuxing,BSLocalizedString("liuxing"))
    menuLiuxing:setPosition(cc.p(640, 320))
    menuLiuxing:registerScriptTapHandler(function()
    end)
    
    local menuHudie = cc.MenuItemImage:create("button.png", "button2.png")
    LuaUtils.BSMenuAdd(self,menuHudie,BSLocalizedString("hudie"))
    menuHudie:setPosition(cc.p(800, 320))
    menuHudie:registerScriptTapHandler(function()
    end)
    
    local menuBoy = cc.MenuItemImage:create("button.png", "button2.png")
    LuaUtils.BSMenuAdd(self,menuBoy,BSLocalizedString("boy"))
    menuBoy:setPosition(cc.p(640, 220))
    menuBoy:registerScriptTapHandler(function()
    end)
    
    local menuGirl = cc.MenuItemImage:create("button.png", "button2.png")
    LuaUtils.BSMenuAdd(self,menuGirl,BSLocalizedString("girl"))
    menuGirl:setPosition(cc.p(800, 220))
    menuGirl:registerScriptTapHandler(function()
    end)
    
    
    local menuEnterGame = cc.MenuItemImage:create("button.png", "button2.png")
    LuaUtils.BSMenuAdd(self,menuEnterGame,BSLocalizedString("enterGame"))
    menuEnterGame:setPosition(cc.p(480, 100))
    menuEnterGame:registerScriptTapHandler(function()
        cc.Director:getInstance():replaceScene(GameLayer:scene())
    end)
    
    
    -- 编辑框的监听函数
    local function onEdit(event, editBox)
        if event == "began" then
            -- 开始输入
            print("开始输入")
        elseif event == "changed" then
            -- 输入框内容发生变化
            print("输入框内容发生变化")
        elseif event == "ended" then
            -- 输入结束
            print("输入结束")
        elseif event == "return" then
            -- 从输入框返回
            print("从输入框返回")
            print("log: ", editBox:getText())
        end
    end

    -- 参数一：创建一个宽500 高73的输入框
    -- 参数二：输入框的背景图片
    local userName = ccui.EditBox:create(cc.size(200, 24), ccui.Scale9Sprite:create("1.png"))
    userName:setInputMode(cc.EDITBOX_INPUT_MODE_ANY)--SINGLE_LINE
    userName:setPosition(cc.p(720, 420)) -- 设置坐标位置
    userName:setFontName("Arial") -- 设置显示字体
    userName:setFontSize(24) -- 设置字体大小
    userName:setFontColor(cc.c3b(255, 255, 255)) -- 设置字体颜色
    userName:setPlaceHolder(BSLocalizedString("name")) -- 设置默认显示文本
    userName:setPlaceholderFontColor(cc.c3b(100, 100, 100)) -- 设置默认显示文本颜色
    userName:setMaxLength(8) -- 设置编辑框的最大输入长度
    userName:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE) -- 设置编辑框的返回类型
    userName:registerScriptEditBoxHandler(onEdit) -- 绑定监听函数
    self:addChild(userName) -- 把编辑框添加到layers层上
end
