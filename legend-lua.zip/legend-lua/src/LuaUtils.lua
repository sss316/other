--LuaUtils set.
cc.exports.LuaUtils={}
math.randomseed(tostring(os.time()):reverse():sub(1,6))

----------------------Schedule-------------------------------------------
function LuaUtils:schedule(target,fun,dt)
    local schedulerID = cc.Director:getInstance():getScheduler():scheduleScriptFunc(fun, dt, false)
    self[schedulerID]=target
    local function onNodeEvent(event)-----on exit function.
        if "exit" == event then
            for k,v in pairs(self) do
                if v==target then
                    cc.Director:getInstance():getScheduler():unscheduleScriptEntry(k)
                    self[k]=nil
                end
            end
        end
    end
    target:registerScriptHandler(onNodeEvent)
end

----------------------touch---------------------------------------------------
function LuaUtils:touch(target,onTouchBegan,onTouchMoved,onTouchEnded)
    local listener = cc.EventListenerTouchOneByOne:create()
    listener:setSwallowTouches(true)
    listener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN )
    if onTouchMoved then listener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED) end
    if onTouchEnded then listener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED) end
    target:getEventDispatcher():addEventListenerWithSceneGraphPriority(listener, target)
end

function LuaUtils:touches(target,onTouchesBegan,onTouchesMoved,onTouchesEnded)
    local listener = cc.EventListenerTouchAllAtOnce:create()
    listener:registerScriptHandler(onTouchesBegan,cc.Handler.EVENT_TOUCHES_BEGAN)
    if onTouchesMoved then listener:registerScriptHandler(onTouchesMoved,cc.Handler.EVENT_TOUCHES_MOVED) end
    if onTouchesEnded then listener:registerScriptHandler(onTouchesEnded,cc.Handler.EVENT_TOUCHES_ENDED ) end
    target:getEventDispatcher():addEventListenerWithSceneGraphPriority(listener, target)
end

----------------table---------------------------------------------------
--print table
function LuaUtils:tablePrint(tab)
    for i,v in pairs(tab) do
        if type(v) == "table" then
            print("table",i,"{")
            self:tablePrint(v)
            print("}")
        else
            print(""..i..":"..v)
        end
    end
end

--copy a new table.
function LuaUtils:tableCopy(t,from)
    for k, v in pairs(from) do
        if type(v) == "table" then
            t[k]={}
            self:tableCopy(t[k],v)
        else
            t[k] = v
        end
    end
end

--add _ for every element.
function LuaUtils:tableAdd_(t)
    local ret = {}
    for k, v in pairs(t) do
        ret["_"..k]=v
    end
    return ret
end

function LuaUtils:tableNum(t)
    local temp = {}
    for k,v in pairs(t) do
        temp[k]=tonumber(v)
    end
    return temp
end

function LuaUtils:tableMinkey(t)
    local value = 9999999
    local key = 0
    for k,v in pairs(t) do
        if v<value then
            value=v
            key=k
        end
    end
    return key
end

----------------point---------------------------------------------------
function LuaUtils:pMult(pt1,pt2)
    return { x = pt1.x * pt2.x , y = pt1.y * pt2.y }
end

function LuaUtils:pEqual(pt1,pt2)
    return pt1.x==pt2.x and pt1.y==pt2.y
end

function LuaUtils:pAngle(self,other)
    return cc.pToAngleSelf(cc.pSub(other,self))
end

----------------string---------------------------------------------------
function LuaUtils:split(sz, sep)
    local start = 1
    local nSplitArray = {}
    while true do
        local last = string.find(sz,sep,start)
        if last then
            table.insert(nSplitArray,string.sub(sz,start,last-1))
            start = last+1
        else
            table.insert(nSplitArray,string.sub(sz,start))
            break
        end
    end
    return nSplitArray
end

----------------action---------------------------------------------------
function LuaUtils:tagAction(target,action,tag)
    action:setTag(tag)
    target:stopActionByTag(tag)
    target:runAction(action)
end

function LuaUtils:animate(name,n,s)
    local ani = cc.Animation:create()
    ani:setDelayPerUnit(s)
    for i=1, n do
        ani:addSpriteFrame(cc.SpriteFrameCache:getInstance():getSpriteFrame(name..i..".png"))
    end
    return cc.Animate:create(ani)
end

-----------------ui-------------------------------------------
function LuaUtils:uiMenu(father,name,pos)
    local s = cc.Sprite:createWithSpriteFrameName(name)
    local s2 = cc.Sprite:createWithSpriteFrameName(name)
    s2:setColor(cc.c3b(200,200,200))
    local submenu = cc.MenuItemSprite:create(s,s2)
    submenu:setPosition(pos)
    local menu = cc.Menu:create(submenu)
    menu:setPosition(0,0)
    father:addChild(menu)
    return submenu
end

function LuaUtils:uiToggle(father,name1,name2,pos)
    local onItem = cc.MenuItemSprite:create(cc.Sprite:createWithSpriteFrameName(name1),cc.Sprite:createWithSpriteFrameName(name1))
    local offItem = cc.MenuItemSprite:create(cc.Sprite:createWithSpriteFrameName(name2),cc.Sprite:createWithSpriteFrameName(name2)) 
    local toggle = cc.MenuItemToggle:create(onItem, offItem)
    toggle:setPosition(pos)
    local menu = cc.Menu:create(toggle)
    menu:setPosition(0,0)
    father:addChild(menu)
    return toggle
end

function LuaUtils:uiLabel(father,name,pos,size)
    local label = cc.Label:createWithSystemFont(name,DEFAULT_FONT_TTF,size)
    label:setPosition(pos)
    father:addChild(label)
    return label
end

function LuaUtils:menuPicPic(father,pic1,pic2,pos)
    local submenu = LuaUtils:uiMenu(father,pic1,pos)
    local show = cc.Sprite:createWithSpriteFrameName(pic2)
    show:setPosition(pos)
    father:addChild(show)
    return submenu
end

function LuaUtils:menuPicText(father,pic1,pic2,pos)
    local submenu = LuaUtils:uiMenu(father,pic1,pos)
    return submenu,LuaUtils:uiLabel(father,pic2,pos,36)
end

function LuaUtils:particle(key)
    for k in pairs(self) do
        if key == k then
            return self[key]
        end
    end
    self[key]=cc.FileUtils:getInstance():getValueMapFromFile(key)
    return self[key]
end


---------------------tabar------------------------------------
cc.exports.BSTabBar = class("BSTabBar",function()
    return cc.Layer:create()
end)

function BSTabBar:ctor()
    self._tabBarArray = {}
    self._labelArray = {}
end

function BSTabBar:setData(t)
    --background
    local background=cc.Sprite:createWithSpriteFrameName("zbbackground.png")
    background:setPosition(cc.p(160,240))
    self:addChild(background)

    local posY = 0.5
    for k,v in pairs(t) do
        local bar = cc.Layer:create()
        self:addChild(bar)
        self._tabBarArray[k] = bar
        if posY>1 then
            bar:setVisible(false)
        end
        

        local menuName = cc.MenuItemSprite:create(cc.Sprite:createWithSpriteFrameName("button.png"),
            cc.Sprite:createWithSpriteFrameName("button2.png"))
        local menuSize = menuName:getContentSize()
        menuName:setPosition(cc.p(-menuSize.width/2, 480-menuSize.height*posY))
        menuName,self._labelArray[k]=LuaUtils.BSMenuAdd(self,menuName,BSLocalizedString(v))
        menuName:registerScriptTapHandler(function()
            for i,j in pairs(self._tabBarArray) do
                if i==k then
                    j:setVisible(true)
                else
                    j:setVisible(false)
                end
            end
        end)
        posY = posY+1
    end
end

function BSTabBar:getTabBar(index)
    return self._tabBarArray[index]
end

function BSTabBar:setString(index,str)
    self._labelArray[index]:setString(str)
end


-----------------menu add label.-------------------------------------------
function LuaUtils.BSMenuAdd(father,child,show)
    local menuChild = cc.Menu:create(child)
    menuChild:setPosition(0,0)
    father:addChild(menuChild)
    local title=nil
    if show then--Thonburi,Helvetica,Marker Felt,Arial
        title = cc.Label:createWithSystemFont(show,"Arial",36)
        child:addChild(title)
        title:setNormalizedPosition(cc.p(0.5,0.5))
        --        title:setPosition(child:getPosition())
        title:setColor(cc.c3b(0, 255, 255))
    end
    return child,title
end

function LuaUtils.getAngle(self,other)
    return cc.pToAngleSelf(cc.pSub(other,self))
end
