cc.exports.UILoadingLayer = class("UILoadingLayer",function()
    return cc.Layer:create()
end)

function UILoadingLayer:scene()
    local scene = cc.Scene:create()
    scene:addChild(UILoadingLayer.new())
    return scene
end

function UILoadingLayer:ctor()
    local size = cc.Director:getInstance():getWinSize()
    local bg = cc.Sprite:createWithSpriteFrameName("door.png")
    bg:setPosition(size.width/2,size.height/2)
    self:addChild(bg)
    bg:setScale(2)
    
    LuaUtils:schedule(self,function(dt)
        cc.Director:getInstance():replaceScene(GameLayer:scene())
    end,0)
end
