cc.exports.Skill={_baseTag=0,_fireCrit={},_fireCritValue=false,_magicShield={},_freezingSpike={}}

--upgrade skill level,bInitRole is first init role.
function Skill:upLevel(role,index,bInitRole)
    local level = role._skillLevel[index]
    if level<=0 then return end
    
    local heroInfo = SkillData[UserInfo:heroName(role._hero)][index]
    local lastLevel = bInitRole and 0 or level-1
    if role._hero==EHero.fighter and index==1 then
        if lastLevel>0 then
            role._defense = role._defense-heroInfo[lastLevel+2]
            role._restore = role._restore-heroInfo[lastLevel+6]
        end
        role._defense = role._defense+heroInfo[level+2]
        role._restore = role._restore+heroInfo[level+6]
    elseif role._hero==EHero.fighter and index==2 then
        if lastLevel>0 then
            role._critRate = role._critRate-heroInfo[lastLevel+2]
            role._critValue = role._critValue-heroInfo[lastLevel+6]
        end
        role._critRate = role._critRate+heroInfo[level+2]
        role._critValue = role._critValue+heroInfo[level+6]
    elseif role._hero==EHero.archmage and index==4 then
        if lastLevel>0 then
            role._restore = role._restore-heroInfo[lastLevel+2]
        end
        role._restore = role._restore+heroInfo[level+2]
    elseif role._hero==EHero.taoist and index==4 then
        if lastLevel>0 then
            role._restore = role._restore-heroInfo[lastLevel+2]
        end
        role._restore = role._restore+heroInfo[level+2]
    end
end

--calculate hurt value. a is attacker, b is beattacker. if double is 3,no crit.
function Skill:calculate(attacker,beattacker,double)
    local lessDefense = beattacker._defense
    local critRate = attacker._critRate
    local critValue = attacker._critValue
    if attacker._camp~=ECamp.monster and attacker._hero==EHero.fighter then
        if double==2 and attacker._skillLevel[3]>0 then   -------assassinate position.  ignore more defense.
            lessDefense = lessDefense-SkillData.fighter[3][attacker._skillLevel[3]+2]
        elseif double==1 and Skill:getFireCrit() then  -------nearly pos
            critRate = 1
            critValue = critValue+SkillData.fighter[4][attacker._skillLevel[4]+2]
        end
    end
    local correct = lessDefense>=0 and lessDefense/10+1 or -1/(lessDefense/10-1)
    local hurt = attacker._hurt/correct*(math.random()*0.2+0.9)
    if double~=3 and math.random()<=critRate then
        hurt = hurt*critValue
    end
    
    
    if attacker._camp==ECamp.monster then
        --not do anything...
    elseif attacker._hero==EHero.fighter then
        --not do anything...
    elseif attacker._hero==EHero.archmage then
        if double==1 then
            if attacker._skillLevel[1]==0 then
            	hurt=0
            else
                hurt = hurt*SkillData.archmage[1][attacker._skillLevel[1]+2]
            end
        end
    end
    return math.floor(hurt+0.5)
end


------------------------------------ add fire crit--------------------------------------------------
function Skill:addFireCrit(role)
    if Skill:getFireCritReady(role) then
        Skill._fireCritValue=true
        LuaUtils:tagAction(_GameLayer,cc.Sequence:create(cc.DelayTime:create(SkillData.fighter[4][7]),
            cc.CallFunc:create(Skill.setFireCritReady,{role})),Skill._baseTag)
        table.insert(Skill._fireCrit,{role,Skill._baseTag})
        Skill._baseTag=Skill._baseTag+1
    end
end

--remove fire crit delay.
function Skill:removeFireCrit()
    Skill._fireCritValue=false
end

function Skill:getFireCrit()
    return Skill._fireCritValue
end

function Skill:setFireCritReady(t)
    local role = t[1]
    for i = #Skill._fireCrit, 1, -1 do
        local v = Skill._fireCrit[i]
        if v[1]==role then
            _GameLayer:stopActionByTag(v[2])
            table.remove(Skill._fireCrit,i)
        end
    end
end

-- get is ready.
function Skill:getFireCritReady(role)
    local bReady = true
    for k, v in pairs(Skill._fireCrit) do
        if v[1]==role then
            bReady = false
            break
        end
    end
    return role._camp~=ECamp.monster and role._hero==EHero.fighter and role._skillLevel[4]>0 and bReady
end


------------------------------------ add Magic Shield--------------------------------------------------
function Skill:addMagicShield(role)
    if Skill:getMagicShieldReady(role) then
        local defense = SkillData.archmage[3][role._skillLevel[3]+2]
        role._defense = role._defense+defense
        local cd = SkillData.archmage[3][11]
        local conti = SkillData.archmage[3][role._skillLevel[3]+6]
        LuaUtils:tagAction(_GameLayer,cc.Sequence:create(cc.DelayTime:create(conti),
            cc.CallFunc:create(Skill.removeMagicShield,{role}),
            cc.DelayTime:create(cd-conti),
            cc.CallFunc:create(Skill.setMagicShieldReady,{role})),Skill._baseTag)
        table.insert(Skill._magicShield,{role,Skill._baseTag,defense})
        Skill._baseTag=Skill._baseTag+1
    end
end

function Skill:removeMagicShield(t)
    local role = t[1]
    for k,v in pairs(Skill._magicShield) do
        if v[1]==role then
            role._defense=role._defense-v[3]
            break
        end
    end
end

function Skill:setMagicShieldReady(t)
    local role = t[1]
    for i = #Skill._magicShield, 1, -1 do
        local v = Skill._magicShield[i]
        if v[1]==role then
            _GameLayer:stopActionByTag(v[2])
            table.remove(Skill._magicShield,i)
        end
    end
end

-- get is ready.
function Skill:getMagicShieldReady(role)
    local bReady = true
    for k, v in pairs(Skill._magicShield) do
        if v[1]==role then
            bReady = false
            break
        end
    end
    return role._camp~=ECamp.monster and role._hero==EHero.archmage and role._skillLevel[3]>0 and bReady
end

------------------------------------ add fire crit--------------------------------------------------
function Skill:addFreezingSpike(role,epos)
    if role._camp~=ECamp.monster and role._hero==EHero.archmage and role._skillLevel[2]>0 then
        for i=epos.y-1, epos.y+1 do
            for j=epos.x-1, epos.x+1 do
                if Skill:getFreezingSpike(cc.p(j,i))==false and UserInfo:isCollision(cc.p(j,i))==false then
                    LuaUtils:tagAction(_GameLayer,cc.Sequence:create(cc.DelayTime:create(conti),
                        cc.CallFunc:create(Skill.removeFreezingSpike,{Skill._baseTag})))
                    table.insert(Skill._freezingSpike,{role,Skill._baseTag,j,i})
                    Skill._baseTag=Skill._baseTag+1
                end
            end
        end
    end
end

function Skill:removeFreezingSpike(t)
    local tag = t[1]
    for i = #Skill._freezingSpike, 1, -1 do
        local v = Skill._freezingSpike[i]
        if v[2]==tag then
            table.remove(Skill._freezingSpike,i)
        end
    end
end

function Skill:removeFreezingSpikeByRole(role)
    for i = #Skill._freezingSpike, 1, -1 do
        local v = Skill._freezingSpike[i]
        if v[1]==role then
            _GameLayer:stopActionByTag(v[2])
            table.remove(Skill._freezingSpike,i)
        end
    end
end

function Skill:getFreezingSpike(epos)
    local bExist = false
    for k, v in pairs(Skill._freezingSpike) do
        if LuaUtils:pEqual(cc.p(v[3],v[4]),epos) then
            bExist = true
            break
        end
    end
    return bExist
end

function Skill:freezingSpikeTimer()
    for key, var in pairs(Skill._freezingSpike) do
        for k, v in pairs(LocalServer._heroArray) do
            local player = var[1]
            if player._camp~=v._camp and LuaUtils:pEqual(cc.p(var[3],var[4]),v._location) then
                Skill:addMagicShield(v)
                --first ,change role locked enemy.
                v._locked = player
                local hurt = Skill:calculate(player,v,3)
                if hurt>0 then
                    v._hp = v._hp-hurt
                    if v._hp<=0 then
                        v._hp=0
                        LocalServer:dead(v,player)
                    end
                    local reply = {action=ESendType.svhp}
                    reply[1] = {rid=v._rid,hp=v._hp}
                    BSSocket:onLine(json.encode(reply).."\n")
                end
            end
        end
    end
end

