cc.exports.LocalServer={}

--refush monster function.
function LocalServer:setUp()
    self._baseMonsterId=1
    self._heroArray={}
    --player
    local hero={
        _rid=UserInfo._rid,
        _location={},
        _level=UserInfo._level,
        _hero=UserInfo._hero,
        _name=UserInfo._name,
        _camp=UserInfo._camp,
        _exp=UserInfo._exp,
        _locked = nil,
        _skillLevel = {},
    }
    LuaUtils:tableCopy(hero._location,UserInfo._bornLocation)
    LuaUtils:tableCopy(hero._skillLevel,UserInfo._skillLevel)
    RoleData:init(hero)
    table.insert(self._heroArray,hero)

    --monster
    LocalServer:refresh(true)
    
    --some timer...
    LuaUtils:schedule(_GameLayer,function(dt)
        LocalServer:onTimer()
    end,1.0)

    LuaUtils:schedule(_GameLayer,function(dt)
        LocalServer:restoreHp()
    end,0.1)

    LuaUtils:schedule(_GameLayer,function(dt)
        LocalServer:oneMinuteTimer()
    end,1)

    LuaUtils:schedule(_GameLayer,function(dt)
        Skill:freezingSpikeTimer()
    end,1)
end

--receive data form client.
function LocalServer:onLine(line)
    local lineTable=json.decode(line)
    if lineTable.action==ESendType.move then
        for k, v in pairs(self._heroArray) do
            if v._rid==lineTable.rid then
                v._location = lineTable.pos
                break
            end
        end
    elseif lineTable.action==ESendType.attack then
        --local server, only send to self.
        local player = LocalServer:roleForRid(lineTable.rid)
        self:dropHp(player,lineTable.hitPos)
    elseif lineTable.action==ESendType.upSkill then
        local player = LocalServer:roleForRid(lineTable.rid)
        player._skillLevel[lineTable.index] = player._skillLevel[lineTable.index]+1
        Skill:upLevel(player,lineTable.index,false)
    end
end

function LocalServer:onTimer()
    for k, v in pairs(self._heroArray) do
        if v._camp==ECamp.monster then
            if v._locked and cc.pGetDistance(v._location,v._locked._location)>8 then v._locked=nil end
            if v._locked==nil then v._locked = self:getNearestEnemy(v) end
            if v._locked then
                --locked role not in attack range,move to destination. or attack dest direct.
                if LocalServer:isOverlap(v) then
                    local x = math.random()>0.5 and 1 or -1
                    local y = math.random()>0.5 and 1 or -1
                    local offset = UserInfo:getOffsetWithColloison(v,cc.p(x,y))
                    if offset then
                        local reply = {action=ESendType.svwalk,
                            rid=v._rid,
                            offset=offset,
                        }
                        BSSocket:onLine(json.encode(reply).."\n")
                        v._location = cc.pAdd(v._location,offset)
                    end
                elseif UserInfo:getAttackRange(v,v._locked) then
                    local reply = {action=ESendType.svattack,
                        rid=v._rid,
                        epos=v._locked._location,
                    }
                    if LuaUtils:pEqual(reply.epos,v._location) then
                        reply.epos=cc.p(reply.epos.x,reply.epos.y-1)
                    end
                    BSSocket:onLine(json.encode(reply).."\n")
                    self:dropHp(v,v._locked._location)
                else
                    local offset = UserInfo:getOffsetWithColloison(v,UserInfo:getV(cc.pSub(v._locked._location,v._location)))
                    if offset then
                        local reply = {action=ESendType.svwalk,
                            rid=v._rid,
                            offset=offset,
                        }
                        BSSocket:onLine(json.encode(reply).."\n")
                        v._location = cc.pAdd(v._location,offset)
                    end
                end
            end
        end
    end
end

--someone attack,drop hp,if dead,then add exp.
function LocalServer:dropHp(player,epos)
--correct right attack position.
    if LuaUtils:pEqual(epos,player._location) then epos=cc.p(epos.x,epos.y-1) end
    
    Skill:addFireCrit(player)
    Skill:addFreezingSpike(player,epos)
    for i=#self._heroArray,1,-1 do
        local v = self._heroArray[i]
        local double = UserInfo:hitEnemy(player,epos,v._location)
        if player._camp~=v._camp and double~=0 then
            Skill:addMagicShield(v)
            --first ,change role locked enemy.
            v._locked = player
            local hurt = Skill:calculate(player,v,double)
            if hurt>0 then
                v._hp = v._hp-hurt
                if v._hp<=0 then
                    v._hp=0
                    LocalServer:dead(v,player)
                end
                local reply = {action=ESendType.svhp}
                reply[1] = {rid=v._rid,hp=v._hp}
                BSSocket:onLine(json.encode(reply).."\n")
            end
        end
    end
    Skill:removeFireCrit()
end

local function gotoRelife(sender,role)
    table.insert(LocalServer._heroArray,role)
    role._hp = role._totalHp
    role._location = {x=UserInfo._bornLocation.x,y=UserInfo._bornLocation.y}
end

function LocalServer:dead(deadRole,attacker)
    Skill:setFireCritReady({deadRole})
    Skill:removeMagicShield({deadRole})
    Skill:setMagicShieldReady({deadRole})
    for i=#self._heroArray,1,-1 do
        if self._heroArray[i]._locked==deadRole then
            self._heroArray[i]._locked=nil
        end
        if self._heroArray[i]==deadRole then
            table.remove(self._heroArray,i)
            if deadRole._camp~=ECamp.monster then
            	_GameLayer:runAction(cc.Sequence:create(cc.DelayTime:create(5),
                    cc.CallFunc:create(gotoRelife,deadRole)))
            end
        end
    end
    
    --send to client.
    if attacker._camp~=ECamp.monster then
        RoleData:addExp(attacker,deadRole._deadExp)
        local reply = {action=ESendType.svExp,rid=attacker._rid,exp=deadRole._deadExp}
        BSSocket:onLine(json.encode(reply).."\n")
    end
end

function LocalServer:getNearestEnemy(role)
    local distance = 99999
    local enemy = nil
    --v is current role, n is enemy.
    for k, v in pairs(self._heroArray) do
        if v._camp~=role._camp then
            local temp = cc.pGetDistance(role._location,v._location)
            if temp<=3 and temp<distance then
                distance = temp
                enemy = v
            end
        end
    end
    return enemy
end

function LocalServer:roleInLocation(location)
    for k, v in pairs(self._heroArray) do
        if LuaUtils:pEqual(v._location,location) then
            return v
        end
    end
    return nil
end

function LocalServer:isOverlap(role)
    for k, v in pairs(self._heroArray) do
        if role~=v and LuaUtils:pEqual(v._location,role._location) then
            return true
        end
    end
    return false
end

function LocalServer:roleForRid(rid)
    for k,v in pairs(self._heroArray) do
        if v._rid==rid then
            return v
        end
    end
    return nil
end

function LocalServer:getCountWithType(hero)
    local count = 0
    for k,v in pairs(self._heroArray) do
        if v._hero==hero and v._camp==ECamp.monster then
            count = count+1
        end
    end
    return count
end

--restore all role's hp
function LocalServer:restoreHp()
    --restore hp
    for k, v in pairs(self._heroArray) do
        v._hp=v._hp+v._restore/10
        if v._hp>v._totalHp then v._hp=v._totalHp end
    end
end

function LocalServer:oneMinuteTimer()
    LocalServer:refresh(false)
end

--refresh all monster.bFirst is or not first load monster.
function LocalServer:refresh(bFirst)
    local time = os.time()
    local reply={action=ESendType.svmonster}
    for k, v in pairs(MapData[UserInfo._map].monster) do
        if bFirst and v[4]<=60 or math.fmod(time,v[4])==0 then
            local count = LocalServer:getCountWithType(v[1])
            for i=count+1,v[3] do
                local hero={
                    _rid=self._baseMonsterId,
                    _hero=v[1],
                    _level=v[2],
                    _locked = nil,
                }
                if v[5] and v[6] then
                    hero._location = cc.p(v[5],v[6])
                else
                    hero._location = UserInfo:getStandLocation()
                end
                RoleData:init(hero)
                table.insert(self._heroArray,hero)
                self._baseMonsterId=self._baseMonsterId+1
                
                
                --send to client----------------
                local index = #reply+1
                reply[index]={
                    rid=hero._rid,
                    location={x=hero._location.x,y=hero._location.y},
                    level=hero._level,
                    hero=hero._hero
                }
                if hero._camp~=ECamp.monster then
                    reply[index].name=hero._name
                    reply[index].camp=hero._camp
                    reply[index].exp=hero._exp
                    reply[index].skillLevel={}
                    LuaUtils:tableCopy(reply[index].skillLevel,hero._skillLevel)
                end
                --end--------------------
            end
        end
    end
    if #reply>=1 then
        BSSocket:onLine(json.encode(reply).."\n")
    end
end
