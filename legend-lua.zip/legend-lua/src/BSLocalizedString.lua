--data
local Localized_en={
    HELLO = "HELLO",
    HELLO2 = "HELLO2",
    maya = "maya",
    localNet = "Local Net",
    setting = "Setting",
    about = "About",
    back = "Back",
    liuxing = "liuxing",
    hudie = "hudie",
    enterGame = "Enter Game",
    fighter = "Fighter",
    magician = "Magician",
    name = "Name",
    boy = "Boy",
    girl = "Girl",
    equipment = "equipment",
    howToPlay = "howToPlay",
    camera = "camera",
    skill = "skill",
    cisha = "cisha",
    experience = "experience",
    hurt = "hurt",
    defense = "defense",
    level = "level",
}

local Localized_zh={
    HELLO = "你好",
    HELLO2 = "你好2",
    maya = "玛雅",
    localNet = "局域网",
    setting = "设置",
    about = "关于",
    back = "返回",
    liuxing = "流星",
    hudie = "蝴蝶",
    enterGame = "开始",
    fighter = "战士",
    magician = "魔法师",
    name = "名字",
    boy = "男",
    girl = "女",
    equipment = "装备",
    howToPlay = "玩法",
    camera = "相机",
    skill = "技能",
    cisha = "刺杀",
    experience = "经验",
    hurt = "攻击力",
    defense = "防御",
    level = "等级",
}

--use current language array.
local curLanguageCode = cc.Application:getInstance():getCurrentLanguageCode()
local switch={}
switch["zh"] = function()cc.exports._BSLocalizedStringArray=Localized_zh end
switch["en"] = function()cc.exports._BSLocalizedStringArray=Localized_en end
switch[curLanguageCode]()

--call by user,change to local language.
function cc.exports.BSLocalizedString(key)
    return _BSLocalizedStringArray[key]
end
