cc.exports.GameLayer = class("GameLayer",function()
    return cc.Layer:create()
end)

function GameLayer:scene()
    local scene = cc.Scene:create()
    scene:addChild(GameLayer.new())
    scene:addChild(UIBattleLayer.new())
    return scene
end

function GameLayer:ctor()
    cc.exports._GameLayer=self

    self._roleArray = {}
    self._collisionMap = {}
    self._cameraOffsetY = 0
    cc.SimpleAudioEngine:getInstance():playMusic("music/background.mp3", true)

    local size = cc.Director:getInstance():getWinSize()

    --add  map
    local detailMapR = { _detailMapSrc = "map/dirt.jpg", _detailMapSize = 35}
    local detailMapG = { _detailMapSrc = "map/Grass2.jpg", _detailMapSize = 35}
    local detailMapB = { _detailMapSrc = "map/road.jpg", _detailMapSize = 35}
    local detailMapA = { _detailMapSrc = "map/GreenSkin.jpg", _detailMapSize = 35}
    local terrainData = { _heightMapSrc = "map/heightmap16.jpg", _alphaMapSrc = "map/alphamap.png" , 
        _detailMaps = {detailMapR, detailMapG, detailMapB, detailMapA}, _detailMapAmount = 4 }

    self._terrain = cc.Terrain:create(terrainData,0) --cc.Terrain.CrackFixedType.SKIRT
    self._terrain:setLODDistance(1000,1000,1000)
    self._terrain:setMaxDetailMapAmount(4)
    self:addChild(self._terrain)
    self._terrain:setCameraMask(2)
    self._terrain:setDrawWire(false)
    self._terrain:setSkirtHeightRatio(3)
    self._terrain:setScale(120)
    self._terrain:setPosition3D(cc.vec3(MapData[UserInfo._map].offset.x,0,MapData[UserInfo._map].offset.y))
    

    local camera = cc.Camera:createPerspective(60.0, size.width/size.height, 10, 4000.0)
--    local camera = cc.Camera:createOrthographic(size.width, size.height, 10.0, 4000.0)
    camera:setCameraFlag(cc.CameraFlag.USER1)
    camera:setPosition3D(cc.vec3(0,300,0))
    camera:setRotation3D(cc.vec3(-60,0,0))
    self:addChild(camera)
    self._camera = camera
    
    --set up timer.
    LuaUtils:schedule(self,function(dt)
    
        --change camera position
        local focusPoint = UserInfo._player:getPosition3D()
        focusPoint.y = focusPoint.y+20
        
        local diff = camera:getPositionY()-focusPoint.y-300
        local height = 0
        if diff<-2 then
            height = camera:getPositionY()+1
        elseif diff>2 then
            height = camera:getPositionY()-1
        else
            height = camera:getPositionY()
        end
        camera:setPosition3D(cc.vec3(focusPoint.x,height,focusPoint.z+300/math.tan(math.rad(60))))
        
        --change role's height
        for k, v in pairs(self._roleArray) do
            local height = self._terrain:getHeight(cc.p(v:getPositionX(),v:getPositionZ()))
            v:setPositionY(height)
        end
    end,0.01)
    
    LuaUtils:schedule(self,function(dt)
        --restore all role's hp
        for k, v in pairs(self._roleArray) do
            if v._state~=ERoleState.dead and v._hp<v._totalHp then
                v._hp=v._hp+v._restore/10
                if v._hp>v._totalHp then v._hp=v._totalHp end
                v._hpTimer:setPercentage(100*v._hp/v._totalHp)
                v._hpNum:setString(math.floor(v._hp).."/"..v._totalHp.." v:"..v._level)
            end
        end
    end,0.1)

    self:runAction(cc.Sequence:create(cc.DelayTime:create(1),cc.CallFunc:create(function()
        LocalServer:setUp()
    end)))

    
    local roledata={
        rid=UserInfo._rid,
        location={},
        level=UserInfo._level,
        hero=UserInfo._hero,
        name=UserInfo._name,
        camp=UserInfo._camp,
        exp=UserInfo._exp,
        skillLevel = {},
    }
    LuaUtils:tableCopy(roledata.location,UserInfo._bornLocation)
    LuaUtils:tableCopy(roledata.skillLevel,UserInfo._skillLevel)
    self:addRole({roledata})

    --Node::setCameraMask(unsigned short mask, bool applyChildren)用来指定cameraMask，其第二个参数用来指明子节点是否递归地使用相同的mask，默认为true。要特别注意：node->setCameraMask(mask,true)只能使node的当前所有子节点的cameraMask设置为mask，但在此之后新添加的子节点则不会受影响（仍然是默认camera），需要记着手动进行设置，这里很容易被坑。又比如在Layer::init()里开头写了一句this->setCameraMask(mask,true)紧接着加了些子节点，那么要意识到这些子节点是不会被设置的，要么对每个子节点都手动调一次setCameraMask，要不就把this->setCameraMask写到init函数的末尾。
    self:setCameraMask(2)
end

function GameLayer:addRole(roleTables)
    for k, v in pairs(roleTables) do
        if type(v) == "table" then
            local pRole = Role.new()
            pRole:init(LuaUtils:tableAdd_(v))
            self:addChild(pRole,1000)
            table.insert(self._roleArray,pRole)
            pRole:setCameraMask(2)
        end
    end
end

function GameLayer:roleForRid(rid)
    for k,v in pairs(self._roleArray) do
        if v._rid==rid then
            return v
        end
    end
    return nil
end

function GameLayer:getNearestEnemy(tempRole)
    local distanceMin = 99999
    local destRole = nil
    for k,v in pairs(_roleArray) do
        local distance=tempRole:getLocation():distance(v:getLocation())
        if tempRole._camp~=v._camp and tempRole._state~="dead" and distance<tempRole._eyeDistance and distance<distanceMin then
            distanceMin=distance
            destRole=v
        end
    end
    return destRole,distanceMin
end

