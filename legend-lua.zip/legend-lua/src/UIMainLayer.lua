cc.exports.UIMainLayer = class("UIMainLayer",function()
    return cc.Layer:create()
end)

function UIMainLayer:scene()
    local scene = cc.Scene:create()
    scene:addChild(UIMainLayer.new())
    return scene
end

function UIMainLayer:ctor()
    local size = cc.Director:getInstance():getWinSize()
    local bg = cc.Sprite:create("door.png")
    bg:setPosition(size.width/2,size.height/2)
    self:addChild(bg)
    bg:setScale(2)
    
    local menuNetWork = cc.MenuItemImage:create("button.png", "button2.png")
    LuaUtils.BSMenuAdd(self,menuNetWork,BSLocalizedString("localNet"))
    menuNetWork:setPosition(cc.p(size.width-100, 400))
    menuNetWork:registerScriptTapHandler(function()
        cc.Director:getInstance():replaceScene(UIRoleLayer:scene())
    end)
    
    local menuSetting = cc.MenuItemImage:create("button.png", "button2.png")
    LuaUtils.BSMenuAdd(self,menuSetting,BSLocalizedString("setting"))
    menuSetting:setPosition(cc.p(size.width-100, 300))
    menuSetting:registerScriptTapHandler(function()
--        CCMessageBox(BSLocalizedString("maya"),BSLocalizedString("maya"))
        print("aaa")
    end)
    
    local menuAbout = cc.MenuItemImage:create("button.png", "button2.png")
    LuaUtils.BSMenuAdd(self,menuAbout,BSLocalizedString("about"))
    menuAbout:setPosition(cc.p(size.width-100, 200))
    menuAbout:registerScriptTapHandler(function()
--        CCMessageBox(BSLocalizedString("maya"),BSLocalizedString("maya"))
        print("bbb")
    end)

end
