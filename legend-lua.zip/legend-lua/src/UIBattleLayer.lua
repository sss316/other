cc.exports.EUIBattle =
    {
        equipment = 1,
        skill = 2,
        howToPlay = 3,
        setting = 4,
        camera = 5,
    }

cc.exports.UIBattleLayer = class("UIBattleLayer",function()
    return cc.Layer:create()
end)

function UIBattleLayer:ctor()
    cc.exports._UIBattleLayer=self
    self._locked=nil

    local size = cc.Director:getInstance():getWinSize()
    local menuBack = cc.MenuItemSprite:create(cc.Sprite:createWithSpriteFrameName("button.png"),
        cc.Sprite:createWithSpriteFrameName("button2.png"))
    menuBack:setPosition(cc.p(100, size.height-50))
    LuaUtils.BSMenuAdd(self,menuBack,BSLocalizedString("setting"))
    menuBack:registerScriptTapHandler(function()
        self._settingLayer:setVisible(not self._settingLayer:isVisible())
    end)

    --tabbar defined.
    self._settingLayer = BSTabBar.new()
    self._settingLayer:setData({"equipment","skill","howToPlay","setting","camera"})
    self:addChild(self._settingLayer)
    self._settingLayer:setPosition(cc.p(600, 100))
    self._settingLayer:setVisible(false)

    --equipment
    local nameLable = cc.LabelTTF:create(UserInfo._name.."("..UserInfo:campName(UserInfo._camp)..")", "Arial", 36)
    self._settingLayer:getTabBar(EUIBattle.equipment):addChild(nameLable)
    nameLable:setPosition(cc.p(160,450))
    nameLable:setColor(cc.c3b(0, 255, 0))

    local propertyName = {"hurt","defense","level","experience"}
    local propertyPos = {cc.p(100,120),cc.p(200,120),cc.p(100,60),cc.p(200,60)}
    for i=1, 4 do
        local blood = cc.Label:createWithSystemFont(BSLocalizedString(propertyName[i]),"Arial",24)
        blood:setColor(cc.c3b(0, 255, 0))
        self._settingLayer:getTabBar(EUIBattle.equipment):addChild(blood)
        blood:setPosition(propertyPos[i])
    end

    --skill
    self._skillUpgradeButton={}
    for i=1, 4 do
        local y = 520-120*i
        local skillIcon = cc.Sprite:createWithSpriteFrameName("skill"..(UserInfo._hero*4-4+i)..".png")
        skillIcon:setPosition(cc.p(50,y+40))
        self._settingLayer:getTabBar(EUIBattle.skill):addChild(skillIcon)
        skillIcon:setScale(0.6)
        local skillInfo = SkillData[UserInfo:heroName(UserInfo._hero)][i]
        local sName = cc.Label:createWithSystemFont(skillInfo[1].."("..UserInfo._player._skillLevel[i]..")","Arial",24)
        sName:setPosition(cc.p(150,y+50))
        sName:setColor(cc.c3b(200,255,200))
        self._settingLayer:getTabBar(EUIBattle.skill):addChild(sName)
        local sDesc = cc.Label:createWithSystemFont(skillInfo[2],"Arial",16)
        sDesc:setPosition(cc.p(20,y))
        sDesc:setColor(cc.c3b(255,200,255))
        sDesc:setAnchorPoint(cc.p(0,1))
        sDesc:setWidth(280)
        self._settingLayer:getTabBar(EUIBattle.skill):addChild(sDesc)
        
        --upgrade button.
        self._skillUpgradeButton[i] = cc.MenuItemSprite:create(cc.Sprite:createWithSpriteFrameName("addskill.png"),
            cc.Sprite:createWithSpriteFrameName("addskill.png"))
        self._skillUpgradeButton[i]:setPosition(cc.p(260,y+50))
        local menu = cc.Menu:create(self._skillUpgradeButton[i])
        menu:setPosition(0,0)
        self._settingLayer:getTabBar(EUIBattle.skill):addChild(menu)
        self._skillUpgradeButton[i]:registerScriptTapHandler(function()
            if UserInfo._player._skillLevel[i]<=3 then
                UserInfo._player._skillLevel[i] = UserInfo._player._skillLevel[i]+1
                Skill:upLevel(UserInfo._player,i,false)
                sName:setString(skillInfo[1].."("..UserInfo._player._skillLevel[i]..")")
                UserInfo._skillPointCount = UserInfo._skillPointCount-1
                self:updateMenuSkill()
                
                --send to server.
                local actionTable={
                    action=ESendType.upSkill,
                    rid=UserInfo._rid,
                    index=i
                }
                BSSocket:send(json.encode(actionTable).."\n")
            end
        end)
    end
    self:updateMenuSkill()

    --setting
    local menuBack = cc.MenuItemSprite:create(cc.Sprite:createWithSpriteFrameName("button.png"),
        cc.Sprite:createWithSpriteFrameName("button2.png"))
    LuaUtils.BSMenuAdd(self._settingLayer:getTabBar(EUIBattle.setting),menuBack,BSLocalizedString("back"))
    menuBack:setPosition(cc.p(100, 100))
    menuBack:registerScriptTapHandler(function()
        cc.Director:getInstance():replaceScene(UIMainLayer:scene())
        _GameLayer = nil
        _UIBattleLayer = nil
    end)


    local movePoint=nil
    --set up timer.
    LuaUtils:schedule(self,function(dt)
        if UserInfo._player._state~=ERoleState.idle and
        UserInfo._player._state~=ERoleState.stand then return end
        if movePoint then
            local offset = {x=0,y=0}
            if movePoint.x<size.width/2-UserInfo._tileSize.x then offset.x=-1 end
            if movePoint.x>size.width/2+UserInfo._tileSize.x then offset.x=1 end
            if movePoint.y<size.height/2-UserInfo._tileSize.y then offset.y=-1 end
            if movePoint.y>size.height/2+UserInfo._tileSize.y then offset.y=1 end
--            if movePoint.x>size.width/3 and movePoint.x<size.width*2/3 and offset.y~=0 then
  --              offset.x=0
    --        end
            if LuaUtils:pEqual(offset,{x=0,y=0})==false then
                self._locked = nil
                UserInfo._player:walk(offset)
            end
        elseif self._locked then
            --locked role not in attack range,move to destination. or attack dest direct.
            if UserInfo:getAttackRange(UserInfo._player,self._locked) then
                UserInfo._player:attack(self._locked._location)
            else
                local pos = cc.pSub(self._locked._location,UserInfo._player._location)
                UserInfo._player:walk(UserInfo:getV(pos))
            end
        end
    end,0.01)
    
    -- handing touch events
    local function onTouchBegan(touch, event)
        if self._settingLayer:isVisible()==false then
            local touchInView = touch[#touch]:getLocationInView()
            local p = _GameLayer._camera:getPosition3D()
            local w = _GameLayer._camera:unproject(cc.vec3(touchInView.x,touchInView.y,1))
            local enemy = nil
            for k,v in pairs(_GameLayer._roleArray) do
                local d = cc.p(v:getPosition())
                local aabb = cc.AABB:new(cc.vec3(d.x-40,d.y-40,v:getPositionZ()),cc.vec3(d.x+40,d.y+40,v:getPositionZ()+60))
                if cc.Ray:new(p,cc.vec3(w.x-p.x,w.y-p.y,w.z-p.z)):intersects(cc.OBB:new(aabb)) and v~=UserInfo._player then
                    enemy = v
                    break
                end
            end
            if enemy then   --attack
                movePoint = nil
                self._locked = enemy
            else   -- move
                movePoint = touch[#touch]:getLocation()
                self._locked = nil
            end
        end
        return true
    end

    local function onTouchMoved(touch, event)
        if self._settingLayer:isVisible() then
            --setting layer move.
            local delta = touch[#touch]:getDelta()
            local pos = cc.p(self._settingLayer:getPosition())
            self._settingLayer:setPosition(cc.pAdd(pos,delta))
        elseif #touch>=2 then
            --set camera degrees and stop walk.
            local temp1 = math.deg(cc.pToAngleSelf(touch[1]:getDelta()))
            local temp2 = math.deg(cc.pToAngleSelf(touch[2]:getDelta()))
            if (temp1>65 and temp1<115 and temp2>65 and temp2<115) or (temp1>-115 and temp1<-65 and temp2>-115 and temp2<-65) then
                _GameLayer._cameraOffsetY = _GameLayer._cameraOffsetY-touch[#touch]:getDelta().y
                self._touchPoint = cc.p(0,0)--stop walk.
            end
        else
            --walk
            movePoint = touch[#touch]:getLocation()
        end
    end

    local function onTouchEnded(touch, event)
        movePoint = nil
    end
    LuaUtils:touches(self,onTouchBegan,onTouchMoved,onTouchEnded)
    self:setCameraMask(1)
end

function UIBattleLayer:updateMenuSkill()
    if UserInfo._skillPointCount>0 then
        for k, v in pairs(self._skillUpgradeButton) do
            v:setVisible(UserInfo._player._skillLevel[k]<=3)
        end
        self._settingLayer:setString(EUIBattle.skill,BSLocalizedString("skill").."("..UserInfo._skillPointCount..")")
    else
        for k, v in pairs(self._skillUpgradeButton) do
            v:setVisible(false)
        end
        self._settingLayer:setString(EUIBattle.skill,BSLocalizedString("skill"))
    end
end

