
cc.FileUtils:getInstance():setPopupNotify(false)
cc.FileUtils:getInstance():addSearchPath("src/")
cc.FileUtils:getInstance():addSearchPath("res/")
cc.FileUtils:getInstance():addSearchPath("res/3d/fighter")
cc.FileUtils:getInstance():addSearchPath("res/3d/archmage")
cc.FileUtils:getInstance():addSearchPath("res/3d/redevilboar")
cc.FileUtils:getInstance():addSearchPath("res/3d/darklord")
cc.FileUtils:getInstance():addSearchPath("res/3d/leftprotector")
cc.FileUtils:getInstance():addSearchPath("res/3d/rightprotector")

require "config"
require "cocos.init"
require ("cocos/cocos2d/json")
require "cocos.3d.3dConstants"
require("LuaUtils")
require("BSC3b")
require("BSLocalizedString")
require("UserInfo")
require("UIRoleLayer")
require("UIBattleLayer")
require("Role")
require("BSSocket")
require("GameLayer")
require("UIMainLayer")
require("RoleData")
require("LocalServer")
require("UILoadingLayer")
require("Skill")

local function main()
    cc.Director:getInstance():setDisplayStats(true)
    
    local particleRes = {}
    for i,v in pairs(particleRes) do
        LuaUtils:particle(v)
    end
    
    local spriteFrameRes = {
        "battle.plist",
    }
    for i,v in pairs(spriteFrameRes) do
        cc.SpriteFrameCache:getInstance():addSpriteFrames(v)
    end


    local gameScene=UILoadingLayer:scene()
    if cc.Director:getInstance():getRunningScene() then
        cc.Director:getInstance():replaceScene(gameScene)
    else
        cc.Director:getInstance():runWithScene(gameScene)
    end
end

local status, msg = xpcall(main, __G__TRACKBACK__)
if not status then
    print(msg)
end
