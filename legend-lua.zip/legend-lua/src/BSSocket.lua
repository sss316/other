
--define and connected to server.

--botsu add for test.
--[[
json = require("json")
local socketFile = require("socket")
BSSocket = socketFile.connect ("localhost", 6002)
if not BSSocket then
    print("not connected!")
else
    print("connected!")
    BSSocket:settimeout(0);
    local actionTable={
        action="oneEnter",
        name=UserInfo._name,
        camp=UserInfo._camp,
        type=UserInfo._type
    }
    BSSocket:send(json.encode(actionTable).."\n")
end
]]--

cc.exports.BSSocket = {}
function BSSocket:send(line)
    LocalServer:onLine(line)
end

function BSSocket:onLine(line)
    local lineTable=json.decode(line)
    --botsu add for test create hero.
    if lineTable.action==ESendType.svhp then
        for k, v in pairs(lineTable) do
            if type(v) == "table" then
                local role = _GameLayer:roleForRid(v.rid)
                role:dropHP(v.hp)
            end
        end
    elseif lineTable.action==ESendType.svattack then
        local role = _GameLayer:roleForRid(lineTable.rid)
        role:attackByServer(lineTable.epos)
    elseif lineTable.action==ESendType.svwalk then
        local role = _GameLayer:roleForRid(lineTable.rid)
        role:walkByServer(lineTable.offset)
    elseif lineTable.action==ESendType.svmonster then
        _GameLayer:addRole(lineTable)
    elseif lineTable.action==ESendType.svExp then
        _GameLayer:addRole(lineTable)
        local role = _GameLayer:roleForRid(lineTable.rid)
        local upGrade = RoleData:addExp(role,lineTable.exp)
        if upGrade then
            UserInfo._skillPointCount = UserInfo._skillPointCount+1
            _UIBattleLayer:updateMenuSkill()
            role._hpTimer:setPercentage(100*role._hp/role._totalHp)
            role._hpNum:setString(""..role._hp.."/"..role._totalHp.." v:"..role._level)
        end
    end
end
