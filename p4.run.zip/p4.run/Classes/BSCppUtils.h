
#ifndef _BSCppUtils_H
#define _BSCppUtils_H

#include "cocos2d.h"
USING_NS_CC;
#include "luaWrapper.h"
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
#include "C2DXShareSDK/C2DXShareSDK.h"
using namespace cn::sharesdk;
#include "platform/android/jni/JniHelper.h"
#endif

#include <string>
using namespace std;

class BSCppUtils
{
public:
	static void registerToLua();
	static void shareInit();
	static void shareGame(string fun);
	static void payByAli(string name,double price);
	static void payByWeiXin(string name,double price);
	static string _shareFun;
};
#endif
