#include "BSCppUtils.h"
#include "baseobject/bmobSDKinit.h"
#include "gamescore.h"


string BSCppUtils::_shareFun = "";


void BSCppUtils::shareInit(){
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
	//init ShareSDK
	C2DXShareSDK::open("a577735f5470", false);
	__Dictionary *wcConfigDict = __Dictionary::create();
	wcConfigDict -> setObject(String::create("wx8dcc37b23ef927cc"), "app_id");
	C2DXShareSDK::setPlatformConfig(C2DXPlatTypeWeixiSession, wcConfigDict);
	C2DXShareSDK::setPlatformConfig(C2DXPlatTypeWeixiTimeline, wcConfigDict);
	
	
	//bmob init...
	BmobSDKInit::initialize("4614130d286b6e8f531f78741a2ff179","198414545acaeae1a05b224ef144a56d");
if (BmobSDKInit::isInitialize())
{
    CCLOG("BmobSDKInit2 initialize is sucess");
}
else{
    CCLOG("BmobSDKInit2 initialize is failed");
}
#endif
}

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
void shareResultHandler(C2DXResponseState state, C2DXPlatType platType, Dictionary *shareInfo, Dictionary *error)
{
	switch (state) {
	case C2DXResponseStateSuccess:
		luaWrapper::call<void,bool>(BSCppUtils::_shareFun.c_str(),true);
		break;
	case C2DXResponseStateFail:
	case C2DXResponseStateCancel:
		luaWrapper::call<void,bool>(BSCppUtils::_shareFun.c_str(),false);
		break;
	default:
		break;
	}
}
#endif

void BSCppUtils::shareGame(string fun){
	BSCppUtils::_shareFun = fun;
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
	Dictionary *content = Dictionary::create();
	content -> setObject(String::create(""), "content");
	content -> setObject(String::create("https://mmbiz.qlogo.cn/mmbiz/EDN8TAPHBbGkJkJdcUhwqXKLshveIKP0SlAiagJLFBrXickicW3P5Dhmt5hcQoVdWYwNYwpMbb0F88kURycFibA3aQ/0?wx_fmt=png"), "image");
	content -> setObject(String::create("我进排行榜了！"), "title");
	content -> setObject(String::create("ccccc"), "description");
	content -> setObject(String::create("http://running.bmob.cn/"), "url");
	content -> setObject(String::createWithFormat("%d", C2DXContentTypeNews), "type");
	content -> setObject(String::create("http://running.bmob.cn/"), "siteUrl");
	content -> setObject(String::create("奔跑的小黑"), "site");
	content -> setObject(String::create("http://mp3.mwap8.com/destdir/Music/2009/20090601/ZuiXuanMinZuFeng20090601119.mp3"), "musicUrl");
	content -> setObject(String::create("extInfo"), "extInfo");
	C2DXShareSDK::showShareMenu(NULL, content, CCPointMake(100, 100), C2DXMenuArrowDirectionLeft,shareResultHandler);
#endif
}

void BSCppUtils::payByAli(string name,double price){
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
	JniMethodInfo minfo;
	jobject activityObj;
	if(JniHelper::getStaticMethodInfo(minfo, "org.cocos2dx.lua.AppActivity", "getInstance","()Ljava/lang/Object;"))
	{
		//调用静态函数getJavaActivity，获取java类对象。
		activityObj = minfo.env->CallStaticObjectMethod(minfo.classID, minfo.methodID);
	}
	if(JniHelper::getMethodInfo(minfo, "org.cocos2dx.lua.AppActivity", "payByAli", "(Ljava/lang/String;D)V"))
	{
		jstring jName = minfo.env->NewStringUTF(name.c_str());
		jdouble jPrice = price;
		minfo.env->CallVoidMethod(activityObj, minfo.methodID, jName,jPrice);
		minfo.env->DeleteLocalRef(jName);
	}
#endif
}

void BSCppUtils::payByWeiXin(string name,double price){
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
	JniMethodInfo minfo;
	jobject activityObj;
	if(JniHelper::getStaticMethodInfo(minfo, "org.cocos2dx.lua.AppActivity", "getInstance","()Ljava/lang/Object;"))
	{
		//调用静态函数getJavaActivity，获取java类对象。
		activityObj = minfo.env->CallStaticObjectMethod(minfo.classID, minfo.methodID);
	}
	if(JniHelper::getMethodInfo(minfo, "org.cocos2dx.lua.AppActivity", "payByWeiXin", "(Ljava/lang/String;D)V"))
	{
		jstring jName = minfo.env->NewStringUTF(name.c_str());
		jdouble jPrice = price;
		minfo.env->CallVoidMethod(activityObj, minfo.methodID, jName,jPrice);
		minfo.env->DeleteLocalRef(jName);
	}
#endif
}

void BSCppUtils::registerToLua(){
	luaWrapper::addFun("shareGame",BSCppUtils::shareGame);
	luaWrapper::addFun("payByAli",BSCppUtils::payByAli);
	luaWrapper::addFun("payByWeiXin",BSCppUtils::payByWeiXin);
	luaWrapper::addFun("findRank",Rank::findRank);
	luaWrapper::addFun("updateRank",Rank::updateRank);
}

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
	extern "C"{
JNIEXPORT void JNICALL Java_org_cocos2dx_lua_AppActivity_payResult(JNIEnv * env, jobject obj,jint jResult)
{
	int result = jResult;
	luaWrapper::call<void,int>("payResult",result);
}
	}
#endif



