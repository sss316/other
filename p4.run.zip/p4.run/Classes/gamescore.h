#ifndef GAMESCORE_H_
#define GAMESCORE_H_

#include <iostream>
#include "cocos2d.h"
#include "cocos-ext.h"
#include "baseobject/bmobSDKinit.h"
#include "baseobject/bmobobject.h"
#include "baseobject/bmobquery.h"
#include "luaWrapper.h"
using namespace std;
USING_NS_CC_EXT;
USING_NS_CC;

class GameScore:public BmobObject{
public:
	GameScore(string tableName);
	virtual ~GameScore();

private:
	CC_SYNTHESIZE(std::string,m_name,Name);
	CC_SYNTHESIZE(int,m_score,Score);
	CC_SYNTHESIZE(string,m_info,Info);
};

class Rank:public BmobFindDelegate,public BmobUpdateDelegate{
public:
	//select data.
	virtual void onFindSucess(const void* data){//To Do
		luaWrapper::call<void,bool,std::string>("rankResult",true,string((char*)data));
		delete this;
	}
	virtual void onFindError(int code,const void* data){//To Do
		delete this;
	}
	static void findRank(){
		BmobQuery* query = new BmobQuery("rank");
    	query->autorelease();
		query->clear();
		query->addQueryKeys("objectId,name,score,clothe");
        query->order("-score");//降序//
    	query->findObjects(new Rank());
	}
	
	
	//update data.
	virtual void onUpdateSucess(const void* data){//To Do
		delete this;
	}
	virtual void onUpdateError(int code,const void* data){//To Do
		delete this;
	}
	static void updateRank(string objectId,string name,int score){
		GameScore* game = new GameScore("rank");
    	game->autorelease();
    	game->clear();
    	game->enParamsToHttp("name",CCString::create(name.c_str()));
    	game->enParamsToHttp("score",CCInteger::create(score));
    	game->update(objectId,new Rank());
	}
};
#endif
