#ifndef _LUAWRAPPER_H
#define _LUAWRAPPER_H

#include <iostream>
#include <string>

#define COCOS2D
#ifdef COCOS2D
#include "CCLuaEngine.h"
#include "cocos2d.h"
USING_NS_CC;
#else
extern "C"
{
#include "lua/lua.h"
#include "lua/lauxlib.h"
#include "lua/lualib.h"
}
#endif



///////////////////////lua template////////////////////////////////
template<typename T> inline T popValue(lua_State *L){ T ret = (T)lua_tonumber(L, -1); lua_pop(L, 1); return ret; }
template<> inline std::string popValue(lua_State *L){ std::string ret = lua_tostring(L, -1); lua_pop(L, 1); return ret; }
template<> inline const char* popValue(lua_State *L){ const char* ret = lua_tostring(L, -1); lua_pop(L, 1); return ret; }
template<> inline bool popValue(lua_State *L){ bool ret = lua_toboolean(L, -1) == 1; lua_pop(L, 1); return ret; }

template<typename T> inline void pushValueT(lua_State *L, const T &var){ lua_pushnumber(L, (lua_Number)var); }
inline void pushValueT(lua_State *L, const char * var){ lua_pushstring(L, var); }
inline void pushValueT(lua_State *L, char * var){ lua_pushstring(L, var); }
inline void pushValueT(lua_State *L, std::string var){ lua_pushstring(L, var.c_str()); }
inline void pushValueT(lua_State *L, bool var){ lua_pushboolean(L, var); }
template<typename T> inline void pushValue(lua_State *L, const T &obj){ pushValueT(L, obj); }

template<typename T>struct TVoidType{ enum { is_Void = 0 }; };
template<>struct TVoidType<void>{ enum { is_Void = 1 }; };
template <int v>struct Int2Type{ enum { value = v }; };

template<typename T>
inline T callT(lua_State *L, int nArgs, int errFunc){ if (lua_pcall(L, nArgs, 1, errFunc) != 0){ lua_pop(L, 1); return T(); }return popValue<T>(L); }
template<>
inline void callT(lua_State *L, int nArgs, int errFunc){ if (lua_pcall(L, nArgs, 0, errFunc) != 0){ lua_pop(L, 1); } }


template<typename Ret> class funbinder{};

//0 parameter
template<typename Ret>
class funbinder<Ret(*)()>{
public:
	typedef Ret(*__func)();
	static int doCall(lua_State *L, __func func, Int2Type<false>){ pushValue<Ret>(L, func()); return 1; }
	static int doCall(lua_State *L, __func func, Int2Type<true>){ func(); return 0; }
	static int lua_cfunction(lua_State *L)
	{
		return doCall(L, (__func)lua_touserdata(L, lua_upvalueindex(1)), Int2Type<TVoidType<Ret>::is_Void>());
	}
};

//1 parameter
template<typename Ret, typename A1>
class funbinder<Ret(*)(A1)>{
public:
	typedef Ret(*__func)(A1);
	static int doCall(lua_State *L, __func func, A1 &a1, Int2Type<false>){ pushValue<Ret>(L, func(a1)); return 1; }
	static int doCall(lua_State *L, __func func, A1 &a1, Int2Type<true>){ func(a1); return 0; }
	static int lua_cfunction(lua_State *L)
	{
		A1 a1 = popValue<A1>(L);
		return doCall(L, (__func)lua_touserdata(L, lua_upvalueindex(1)), a1, Int2Type<TVoidType<Ret>::is_Void>());
	}
};

//2 parameter
template<typename Ret, typename A1, typename A2>
class funbinder<Ret(*)(A1, A2)>{
public:
	static int lua_cfunction(lua_State *L)
	{
		A2 a2 = popValue<A2>(L);
		A1 a1 = popValue<A1>(L);
		return doCall(L, (__func)lua_touserdata(L, lua_upvalueindex(1)), a1, a2, Int2Type<TVoidType<Ret>::is_Void>());
	}
	typedef Ret(*__func)(A1, A2);
	static int doCall(lua_State *L, __func func, A1 &a1, A2 a2, Int2Type<false>){ pushValue<Ret>(L, func(a1, a2)); return 1; }
	static int doCall(lua_State *L, __func func, A1 &a1, A2 a2, Int2Type<true>){ func(a1, a2); return 0; }
};

//3 parameter
template<typename Ret, typename A1, typename A2, typename A3>
class funbinder<Ret(*)(A1, A2, A3)>{
public:
	static int lua_cfunction(lua_State *L)
	{
		A3 a3 = popValue<A3>(L);
		A2 a2 = popValue<A2>(L);
		A1 a1 = popValue<A1>(L);
		return doCall(L, (__func)lua_touserdata(L, lua_upvalueindex(1)), a1, a2, a3, Int2Type<TVoidType<Ret>::is_Void>());
	}
	typedef Ret(*__func)(A1, A2, A3);
	static int doCall(lua_State *L, __func func, A1 &a1, A2 a2, A3 &a3, Int2Type<false>){ pushValue<Ret>(L, func(a1, a2, a3)); return 1; }
	static int doCall(lua_State *L, __func func, A1 &a1, A2 a2, A3 &a3, Int2Type<true>){ func(a1, a2, a3); return 0; }
};

//4 parameter
template<typename Ret, typename A1, typename A2, typename A3, typename A4>
class funbinder<Ret(*)(A1, A2, A3, A4)>{
public:
	static int lua_cfunction(lua_State *L)
	{
		A4 a4 = popValue<A4>(L);
		A3 a3 = popValue<A3>(L);
		A2 a2 = popValue<A2>(L);
		A1 a1 = popValue<A1>(L);
		return doCall(L, (__func)lua_touserdata(L, lua_upvalueindex(1)), a1, a2, a3, a4, Int2Type<TVoidType<Ret>::is_Void>());
	}
	typedef Ret(*__func)(A1, A2, A3, A4);
	static int doCall(lua_State *L, __func func, A1 &a1, A2 a2, A3 &a3, A4 &a4, Int2Type<false>){ pushValue<Ret>(L, func(a1, a2, a3, a4)); return 1; }
	static int doCall(lua_State *L, __func func, A1 &a1, A2 a2, A3 &a3, A4 &a4, Int2Type<true>){ func(a1, a2, a3, a4); return 0; }
};

//use this class...
class luaWrapper
{
public:
	static lua_State* getState(){
		static lua_State* lState = NULL;
		if (lState == NULL){
#ifdef COCOS2D
			lState = LuaEngine::getInstance()->getLuaStack()->getLuaState();
#else
			lState = luaL_newstate();
			luaL_openlibs(lState);
#endif
		}
		return lState;
	}
	static bool dofile(const char *filename){
		if (luaL_dofile(getState(), filename)) {
			const char * error = lua_tostring(getState(), -1);
			lua_pop(getState(), 1);
			return false;
		}
		return true;
	}


	///////////////////////lua call c++////////////////////////////////
	template<typename FUNTOR>
	static void addFun(const char *name, FUNTOR _func)
	{
		lua_State *L = getState();
		lua_pushlightuserdata(L, (void*)_func);
		lua_pushcclosure(L, funbinder<FUNTOR>::lua_cfunction, 1);
		lua_setglobal(L, name);
	}


	///////////////////////////////c++ call lua///////////////////////////////////////////////////////////////////////
	template<typename Ret>
	static Ret call(const char *funname)
	{
		lua_State *L = getState();
		lua_getglobal(L, funname);
		return callT<Ret>(L, 0, 0);
	}

	template<typename Ret, typename A1>
	static Ret call(const char *funname, const A1 &a1)
	{
		lua_State *L = getState();
		lua_getglobal(L, funname);
		pushValue<A1>(L, a1);
		return callT<Ret>(L, 1, 0);
	}

	template<typename Ret, typename A1, typename A2>
	static Ret call(const char *funname, const A1 &a1, const A2 &a2)
	{
		lua_State *L = getState();
		lua_getglobal(L, funname);
		pushValue<A1>(L, a1);
		pushValue<A2>(L, a2);
		return callT<Ret>(L, 2, 0);
	}

	template<typename Ret, typename A1, typename A2, typename A3>
	static Ret call(const char *funname, const A1 &a1, const A2 &a2, const A3 &a3)
	{
		lua_State *L = getState();
		lua_getglobal(L, funname);
		pushValue<A1>(L, a1);
		pushValue<A2>(L, a2);
		pushValue<A3>(L, a3);
		return callT<Ret>(L, 3, 0);
	}

	template<typename Ret, typename A1, typename A2, typename A3, typename A4>
	static Ret call(const char *funname, const A1 &a1, const A2 &a2, const A3 &a3, const A4 &a4)
	{
		lua_State *L = getState();
		lua_getglobal(L, funname);
		pushValue<A1>(L, a1);
		pushValue<A2>(L, a2);
		pushValue<A3>(L, a3);
		pushValue<A4>(L, a4);
		return callT<Ret>(L, 4, 0);
	}
};

#endif
