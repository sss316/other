#include "gamescore.h"

GameScore::GameScore(string tableName):
BmobObject(tableName){

}

GameScore::~GameScore(){

}