/**
* delegate implementions
*/

#include "bmobdelegate.h"