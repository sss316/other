/**
* delegate of bmob sdk
*/
#ifndef BMOBSDK_BMOBDELEGATE_H_
#define BMOBSDK_BMOBDELEGATE_H_

#include "bmobsavedelegate.h"
#include "bmobupdatedelegate.h"
#include "bmobfinddelegate.h"
#include "bmobgetdelegate.h"
#include "bmobcountdelegate.h"
#include "bmobstaticsdelegate.h"
#include "bmobdeletedelegate.h"
#include "bmobresetpassworddelegate.h"
#include "bmobrequestSMScodedelegate.h"
#include "bmobresetpasswordbycodedelegate.h"
#include "bmobemailverifydelegate.h"
#include "bmoblogindelegate.h"

#endif