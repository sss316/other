cc.exports.WinLayer = class("WinLayer",function()
    return cc.Layer:create()
end)

function WinLayer:ctor()
    UserInfo._winLayer = self
    LuaUtils:touch(self,function(touch, event)return true end,nil,nil)
    local size = cc.Director:getInstance():getWinSize()
    local back = cc.Sprite:createWithSpriteFrameName("setting-plane.png")
    back:setPosition(size.width/2,size.height/2)
    self:addChild(back)


	LuaUtils:uiLabel(self,"奖状",cc.p(size.width/2,800),96)
	LuaUtils:uiLabel(self,"哇，你冲刺了"..math.floor(UserInfo._curDistance/20).."米！",cc.p(size.width/2,600),72)
    
    
    local gotoMenu = LuaUtils:menuPicPic(self,"menuback2.png","home.png",cc.p(size.width/2-220,300))
    gotoMenu:registerScriptTapHandler(function()
        UserInfo._winLayer = nil
        cc.Director:getInstance():replaceScene(FirstLayer:scene())
    end)
    local goOn = LuaUtils:menuPicPic(self,"menuback2.png","try.png",cc.p(size.width/2+220,300))
    goOn:registerScriptTapHandler(function()
        UserInfo._winLayer = nil
        cc.Director:getInstance():replaceScene(GameLayer:scene())
    end)
    
    --particle
    for i=1, 10 do
        local particle = cc.ParticleSystemQuad:create("particles_btn_star.plist")
        particle:setPosition(size.width/2,size.height/2)
        self:addChild(particle)
        particle:setScale(3+4.5*math.random())
        particle:setAutoRemoveOnFinish(true)
        local switch = {}
        switch[1]=cc.c4f(255,0,0,255)
        switch[2]=cc.c4f(0,255,0,255)
        switch[3]=cc.c4f(255,255,0,255)
        particle:setStartColorVar(switch[math.random(1,3)])
        particle:setEndColorVar(switch[math.random(1,3)])
        particle:stopSystem()
        particle:runAction(cc.Sequence:create(cc.DelayTime:create(math.random()*2),
            cc.CallFunc:create(function()particle:resetSystem()end)))
    end
    
    --true rank...
    findRank()
    function WinLayer:showRank(rank)
        LuaUtils:uiLabel(self,"排行榜",cc.p(1600,980),48)
        for k, v in ipairs(rank) do
            if v["name"]=="" then
            	v["name"]="无名"
            end
            LuaUtils:uiLabel(self,""..k..".  "..v["name"].."  "..v["score"],cc.p(1600,980-k*80),48)
    	end
    end
end

