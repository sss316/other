cc.exports.ShowYou = class("ShowYou",function()return cc.Node:create()end)

function ShowYou:ctor()
    self._rgba = cc.c4f(168/255,208/255,222/255,1)
    self._top = 500
    self._drawYou1 = cc.DrawNode:create()
    self:addChild(self._drawYou1)

    self._drawYou2 = cc.DrawNode:create()
    self:addChild(self._drawYou2)
    
	self._youLabel = LuaUtils:uiLabel(self,"You",cc.p(0,0),72)
    self._youLabel:setAnchorPoint(0.5,0)
    self._youLabel:setColor(cc.c3b(255*self._rgba.r,255*self._rgba.g,255*self._rgba.b))
end

function ShowYou:updatePos()
    local playerHat = cc.pAdd(cc.p(_GameLayer._player:getPosition()),cc.p(0,183))
    if self._top>playerHat.y+50 then
        self._top=self._top-1
    else
        self._top = playerHat.y+50
        if self._top>1000 then self._top = 1000 end
    end

    self._drawYou1:clear()
    self._drawYou1:drawLine(playerHat,cc.p(playerHat.x,self._top),self._rgba)
    self._drawYou2:clear()
    self._drawYou2:drawLine(cc.p(playerHat.x-20,self._top),cc.p(playerHat.x+20,self._top),self._rgba)
    self._youLabel:setPosition(cc.p(playerHat.x,self._top))
end
