cc.exports.UserInfo = {}

UserInfo._TagJumpEnd = 245
UserInfo._TagDead = 246

UserInfo._curDistance = 0
UserInfo._heroChoose = nil
UserInfo._winLayer = nil
UserInfo._payID = 1

function UserInfo:readConfig()
    UserInfo._name = cc.UserDefault:getInstance():getStringForKey("name","")
    UserInfo._music = cc.UserDefault:getInstance():getIntegerForKey("music",1)
    UserInfo._effect = cc.UserDefault:getInstance():getIntegerForKey("effect",1)
    cc.SimpleAudioEngine:getInstance():setMusicVolume(UserInfo._music)
    cc.SimpleAudioEngine:getInstance():setEffectsVolume(UserInfo._effect)
    UserInfo._selectedHero = cc.UserDefault:getInstance():getIntegerForKey("selectedHero",1)
    local tempBuy = cc.UserDefault:getInstance():getStringForKey("buy","1,0,0,0,0,0")
    UserInfo._buy=LuaUtils:tableNum(LuaUtils:split(tempBuy,","))
end

function UserInfo:addHat(father,hero,num)
    if num~=1 then
        local hat = cc.Sprite:createWithSpriteFrameName("herohat-"..num..".png")
        father:addChild(hat)
        if num==2 then
            hat:setPosition(cc.pAdd(cc.p(hero:getPosition()),cc.p(-45,75)))
        elseif num==3 then
            hat:setPosition(cc.pAdd(cc.p(hero:getPosition()),cc.p(-40,50)))
        elseif num==4 then
            hat:setPosition(cc.pAdd(cc.p(hero:getPosition()),cc.p(-45,55)))
        elseif num==5 then
            hat:setPosition(cc.pAdd(cc.p(hero:getPosition()),cc.p(-20,65)))
        elseif num==6 then
            hat:setPosition(cc.pAdd(cc.p(hero:getPosition()),cc.p(-35,30)))
        end
    end
end

function cc.exports.payResult(result)
    print("result:"..result)
    if result==1 then
        num = UserInfo._payID
        UserInfo._buy[num] = 1
        cc.UserDefault:getInstance():setStringForKey("buy",table.concat(UserInfo._buy,","))
        if UserInfo._heroChoose ~= nil then
            UserInfo._heroChoose:removeChildByTag(1000+num)
        end
    end
end


function cc.exports.rankResult(result,data)
    local myscore = math.floor(UserInfo._curDistance/20)
    local rank=json.decode(data).results
    if myscore>rank[10].score then
        updateRank(rank[10].objectId,UserInfo._name=="" and "无名" or UserInfo._name,myscore)
        rank[10].score=myscore
        rank[10].name=UserInfo._name
    end
    table.sort(rank,function(a,b) return a.score>b.score end )
    print(LuaUtils:tablePrint(rank))
    if UserInfo._winLayer then
        UserInfo._winLayer:showRank(rank)
    end
end

