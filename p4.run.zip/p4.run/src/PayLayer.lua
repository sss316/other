cc.exports.PayLayer = class("PayLayer",function()
    return cc.Layer:create()
end)

function PayLayer:ctor()
    LuaUtils:touch(self,function(touch, event)return true end,nil,nil)
    local size = cc.Director:getInstance():getWinSize()
    local back = cc.Sprite:createWithSpriteFrameName("pay_back.png")
    back:setPosition(size.width/2,size.height/2)
    back:setScale(3)
    self:addChild(back)

	local miLabel = LuaUtils:uiLabel(self,"支付方式",cc.p(880,930),32)
    miLabel:setColor(cc.c3b(0,0,0))
    miLabel:setScale(4)

    local weixin = LuaUtils:uiMenu(self,"pay_weixin.png",cc.p(550,600))
    weixin:setScale(2)
    weixin:registerScriptTapHandler(function()
        payByWeiXin("奔跑的小黑",1)
    end)
    local ali = LuaUtils:uiMenu(self,"pay_ali.png",cc.p(1150,600))
    ali:setScale(2)
    ali:registerScriptTapHandler(function()
        payByAli("奔跑的小黑",1)
    end)
    
    --back
    local close = LuaUtils:menuPicPic(self,"menuback1.png","back.png",cc.p(840,200))
    close:registerScriptTapHandler(function()
        cc.SimpleAudioEngine:getInstance():playEffect("menu.wav")
        self:removeFromParent()
    end)
end
