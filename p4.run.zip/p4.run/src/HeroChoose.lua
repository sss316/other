cc.exports.HeroChoose = class("HeroChoose",function()
    return cc.Layer:create()
end)

function HeroChoose:scene()
    local scene = cc.Scene:create()
    local layer = HeroChoose.new()
    scene:addChild(layer)
    return scene
end

function HeroChoose:ctor()
    UserInfo._heroChoose = self
    local size = cc.Director:getInstance():getWinSize()
    local back = cc.Sprite:create("back-first.png")
    back:setPosition(size.width/2,size.height/2)
    self:addChild(back)
    back:runAction(cc.RepeatForever:create(cc.Sequence:create(
        cc.TintTo:create(1,255,150,150),
        cc.TintTo:create(2,255,255,255),
        cc.TintTo:create(1,150,255,150),
        cc.TintTo:create(2,255,255,255),
        cc.TintTo:create(1,150,150,255),
        cc.TintTo:create(2,255,255,255)
    )))
    
    
    --title
    local back = LuaUtils:menuPicPic(self,"menuback1.png","herosel.png",cc.p(size.width-120,size.height-100))
    back:registerScriptTapHandler(function()
    end)
    
    --back
    local back = LuaUtils:menuPicPic(self,"menuback1.png","back.png",cc.p(size.width/2,100))
    back:registerScriptTapHandler(function()
        cc.SimpleAudioEngine:getInstance():playEffect("menu.wav")
        cc.UserDefault:getInstance():setIntegerForKey("selectedHero",UserInfo._selectedHero)
        cc.Director:getInstance():replaceScene(FirstLayer:scene())
        UserInfo._heroChoose = nil
    end)
    
    

    local heroselSprite = cc.Sprite:createWithSpriteFrameName("heroback-sel.png")
    self:addChild(heroselSprite)
    
    for i=1, 2 do
    	for j=1, 3 do
            local num = (i-1)*3+j
            
            --hero menu.
            local sp2 = LuaUtils:uiMenu(self,"heroback.png",cc.p(100+400*j,1100-350*i))
            sp2:registerScriptTapHandler(function()
                cc.SimpleAudioEngine:getInstance():playEffect("menu.wav")
                if UserInfo._buy[num]==0 then
                    UserInfo._payID = num
                    
                    
                    --no pay
                    self:addChild(PayLayer.new(),9)
--                    UserInfo._buy[num] = 1
--                    cc.UserDefault:getInstance():setStringForKey("buy",table.concat(UserInfo._buy,","))
--                    self:removeChildByTag(1000+num)
                else
                    UserInfo._selectedHero = num
                    heroselSprite:setPosition(cc.p(sp2:getPosition()))
                end
            end)
            
            --hero picture.
            local hero = cc.Sprite:createWithSpriteFrameName("heropic.png")
            hero:setPosition(cc.p(sp2:getPosition()))
            self:addChild(hero)
            UserInfo:addHat(self,hero,num)

            
            --buy label.
            if UserInfo._buy[num]==0 then
                local money = cc.Sprite:createWithSpriteFrameName("heromoney.png")
                money:setPosition(cc.pAdd(cc.p(hero:getPosition()),cc.p(30,-85)))
                money:setTag(1000+num)
                self:addChild(money)
            end

            --update select hero.
            if num==UserInfo._selectedHero then
                heroselSprite:setPosition(cc.p(sp2:getPosition()))
            end
    	end
    end
end
