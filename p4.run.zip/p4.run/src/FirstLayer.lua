cc.exports.FirstLayer = class("FirstLayer",function()
    return cc.Layer:create()
end)

function FirstLayer:scene()
    local scene = cc.Scene:create()
    local layer = FirstLayer.new()
    scene:addChild(layer)
    return scene
end

function FirstLayer:ctor()
    UserInfo._firstLayer = self
    local size = cc.Director:getInstance():getWinSize()
    local back = cc.Sprite:create("back-first.png")
    back:setPosition(size.width/2,size.height/2)
    self:addChild(back)
    back:runAction(cc.RepeatForever:create(cc.Sequence:create(
    cc.TintTo:create(1,255,150,150),
    cc.TintTo:create(2,255,255,255),
    cc.TintTo:create(1,150,255,150),
    cc.TintTo:create(2,255,255,255),
    cc.TintTo:create(1,150,150,255),
    cc.TintTo:create(2,255,255,255)
    )))
    
    local running = cc.Sprite:createWithSpriteFrameName("running.png")
    running:setPosition(size.width/2,size.height-200)
    self:addChild(running)

    local herosel = cc.Sprite:createWithSpriteFrameName("herosel.png")
    herosel:setPosition(200,100)
    self:addChild(herosel)
	
    self._setting = LuaUtils:uiMenu(self,"setting.png",cc.p(100,size.height-100))
    self._setting:registerScriptTapHandler(function()
        cc.SimpleAudioEngine:getInstance():playEffect("menu.wav")
        self._setting:setEnabled(false)
        local layer = SettingLayer.new()
        self:addChild(layer,10)
    end)
    local heropic = LuaUtils:uiMenu(self,"heropic.png",cc.p(200,200))
    heropic:registerScriptTapHandler(function()
        cc.SimpleAudioEngine:getInstance():playEffect("menu.wav")
        cc.Director:getInstance():replaceScene(HeroChoose:scene())
    end)
    


    function cc.exports.shareEnd(b)
        local size = cc.Director:getInstance():getWinSize()
		local back = LuaUtils:uiLabel(self,b and "分享成功！~" or "分享失败！~",cc.p(size.width-250,400),48)
        back:setScale(0)
        back:setColor(cc.c3b(0,0,255))
        back:runAction(cc.Sequence:create(
            cc.Spawn:create(cc.MoveBy:create(0.5,cc.p(0,100)),cc.ScaleTo:create(0.5,1)),
            cc.DelayTime:create(1),
            cc.MoveBy:create(1,cc.p(0,200)),
            cc.FadeOut:create(0.2),
            cc.RemoveSelf:create()))
    end
    
    local share = LuaUtils:uiMenu(self,"share.png",cc.p(size.width-250,400))
    share:registerScriptTapHandler(function()
        cc.SimpleAudioEngine:getInstance():playEffect("menu.wav")
        shareGame("shareEnd")
    end)
    
    local play = LuaUtils:uiMenu(self,"play.png",cc.p(size.width/2,400))
    play:registerScriptTapHandler(function()
        cc.SimpleAudioEngine:getInstance():playEffect("menu.wav")
        cc.Director:getInstance():replaceScene(GameLayer:scene())
    end)
    
    --hat of hero.
    UserInfo:addHat(self,heropic,UserInfo._selectedHero)
    
    --分享tips
	local tips = LuaUtils:uiLabel(self,"点我分享！",cc.p(share:getPosition()),48)
    tips:setScale(0)
    tips:setColor(cc.c3b(0,0,255))
    tips:runAction(cc.Sequence:create(
        cc.Spawn:create(cc.MoveBy:create(0.5,cc.p(0,100)),cc.ScaleTo:create(0.5,1)),
        cc.DelayTime:create(1),
        cc.MoveBy:create(1,cc.p(0,200)),
        cc.FadeOut:create(0.2),
        cc.RemoveSelf:create()))
        



    local function editBoxTextEventHandle(strEventName,pSender)
        local edit = pSender
        local strFmt 
        if strEventName == "began" then
            strFmt = string.format("editBox %p DidBegin !", edit)
            print(strFmt)
        elseif strEventName == "ended" then
            strFmt = string.format("editBox %p DidEnd !", edit)
            print(strFmt)
        elseif strEventName == "return" then
            strFmt = string.format("editBox %p was returned !",edit)
            print(strFmt)
        elseif strEventName == "changed" then
            strFmt = string.format("editBox %p TextChanged, text: %s ", edit, edit:getText())
            print(strFmt)
            UserInfo._name=edit:getText()
            cc.UserDefault:getInstance():setStringForKey("name",UserInfo._name)
        end
    end
    -- top
    local EditName = ccui.EditBox:create(cc.size(300, 100),"xxxxaaaaaa.png")
    EditName:setText(UserInfo._name)
    EditName:setPosition(cc.p(1650,100))
--    EditName:setFontName("Paint Boy")
    EditName:setFontSize(25)
    EditName:setFontColor(cc.c3b(160,32,240))
    EditName:setPlaceHolder("name")
    EditName:setPlaceholderFontColor(cc.c3b(100,100,100))
    EditName:setMaxLength(3)
    EditName:setReturnType(1)  --cc.KEYBOARD_RETURNTYPE_DONE
    EditName:setInputMode(6)   --cc.EDITBOX_INPUT_MODE_SINGLELINE
    --Handler
    EditName:registerScriptEditBoxHandler(editBoxTextEventHandle)
    self:addChild(EditName)
end


