cc.exports.LoadingLayer = class("LoadingLayer",function()
    return cc.Layer:create()
end)

function LoadingLayer:scene()
    local scene = cc.Scene:create()
    local layer = LoadingLayer.new()
    scene:addChild(layer)
    return scene
end

function LoadingLayer:ctor()
    local size = cc.Director:getInstance():getWinSize()
    local back = cc.Sprite:create("yindao.jpg")
    back:setPosition(size.width/2,size.height/2)
    self:addChild(back)
    local label = LuaUtils:uiLabel(self,"loading...",cc.p(size.width-300,200),96)
    label:setColor(cc.c3b(168,208,222))
    
    LuaUtils:schedule(self,function(dt)
        for i=1, 10 do
            cc.Director:getInstance():getTextureCache():addImage(""..i..".jpg")
        end

        cc.SpriteFrameCache:getInstance():addSpriteFrames("feng.plist")
        cc.SpriteFrameCache:getInstance():addSpriteFrames("decoration_black.plist")
        cc.SpriteFrameCache:getInstance():addSpriteFrames("decoration_blue.plist")
        cc.SpriteFrameCache:getInstance():addSpriteFrames("decoration_green.plist")
        cc.SpriteFrameCache:getInstance():addSpriteFrames("decoration_red.plist")

        UserInfo:readConfig()
        local colors = {"red","green","black","blue"}
        if UserInfo._colorName=="red" then UserInfo._colorName = "green"
        elseif UserInfo._colorName=="green" then UserInfo._colorName = "black"
        elseif UserInfo._colorName=="black" then UserInfo._colorName = "blue"
        elseif UserInfo._colorName=="blue" then UserInfo._colorName = "red"
        else UserInfo._colorName = colors[math.random(1,4)] end
        cc.Director:getInstance():replaceScene(LogoPageLayer:scene())
    end,0)
end
