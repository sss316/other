cc.exports.UIBattleLayer = class("UIBattleLayer",function()
    return cc.Layer:create()
end)

function UIBattleLayer:ctor()

    --touch event
    local function onTouchBegan(touch, event)
        --setting layer dispose.
        if _GameLayer._player then
            table.insert(_GameLayer._player._data,_GameLayer._player:getPositionX())
            if _GameLayer._player._jumpNum==0 then
                cc.SimpleAudioEngine:getInstance():playEffect("jump.ogg")
            elseif _GameLayer._player._jumpNum==1 then
                cc.SimpleAudioEngine:getInstance():playEffect("double_jump.ogg")
            end
            _GameLayer._player:touchBegin()
        end
        return true
    end
    local function onTouchEnd(touch, event)
        if _GameLayer._player then
            table.insert(_GameLayer._player._data,_GameLayer._player:getPositionX())
            _GameLayer._player:touchEnd()
        end
    end
    LuaUtils:touch(self,onTouchBegan,nil,onTouchEnd)
end
