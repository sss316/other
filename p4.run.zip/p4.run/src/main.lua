
cc.FileUtils:getInstance():setPopupNotify(false)
cc.FileUtils:getInstance():addSearchPath("src/")
cc.FileUtils:getInstance():addSearchPath("res/")


require "config"
require "cocos.init"
require("cocos/cocos2d/json")
require("UserInfo")
require "LuaUtils"
require("Role")
require("UIBattleLayer")
require("GameLayer")
require("FirstLayer")
require("SettingLayer")
require("WinLayer")
require("HeroChoose")
require("ShowYou")
require("PayLayer")
require("LogoPageLayer")
require("LoadingLayer")

local function main()
    if CC_SHOW_FPS then
        cc.Director:getInstance():setDisplayStats(true)
    end

    local gameScene=LoadingLayer:scene()
    if cc.Director:getInstance():getRunningScene() then
        cc.Director:getInstance():replaceScene(gameScene)
    else
        cc.Director:getInstance():runWithScene(gameScene)
    end
end

local status, msg = xpcall(main, __G__TRACKBACK__)
if not status then
    print(msg)
end
