cc.exports.LogoPageLayer = class("LogoPageLayer",function()
    return cc.Layer:create()
end)

function LogoPageLayer:scene()
    local scene = cc.Scene:create()
    local layer = LogoPageLayer.new()
    scene:addChild(layer)
    return scene
end

function LogoPageLayer:ctor()
    local begin = false
    local girdIndex = 1
    local size = cc.Director:getInstance():getWinSize()
--[[
    local pageView = ccui.PageView:create()
    pageView:setTouchEnabled(true)
    pageView:setContentSize(size)
--    pageView:setDirection(ccui.PageViewDirection.HORIZONTAL)
    pageView:setPosition(cc.p(0,0))
    self:addChild(pageView)
    
    for i = 1 , 6 do
        local layout = ccui.Layout:create()
        layout:setContentSize(size)

        local imageView = ccui.ImageView:create()
        imageView:setTouchEnabled(true)
        imageView:setScale9Enabled(true)
        imageView:loadTexture(""..i..".jpg")
        imageView:setContentSize(size)
        imageView:setPosition(cc.p(layout:getContentSize().width / 2, layout:getContentSize().height / 2))
        layout:addChild(imageView)
        

        
        local label = ccui.Text:create()
        local pageInfo = string.format("第%d页", i)
        label:setString(pageInfo)
        label:setFontName(font_TextName)
        label:setFontSize(72)
        label:setColor(cc.c3b(255,0,0))
        label:setPosition(cc.p(size.width/2,100))
        layout:addChild(label)

        if i==6 then
            local play = LuaUtils:uiMenu(layout,"go.png",cc.p(1320,630))
            play:registerScriptTapHandler(function()
                cc.SimpleAudioEngine:getInstance():playEffect("menu.wav")
                cc.Director:getInstance():replaceScene(FirstLayer:scene())
            end)
        else
            local next = LuaUtils:uiLabel(layout,">>>",cc.p(size.width-100,size.height/2),96)
            next:setColor(cc.c3b(255,0,0))
        end
        
        pageView:addPage(layout)
    end
    ]]--
    
    LuaUtils:schedule(self,function(dt)
        begin=true
    end,0)
    
    local gridArray = {}
    for i = 10 , 1,-1 do
        local grid = cc.NodeGrid:create()
        grid:setPosition(cc.p(0,0))
        self:addChild(grid)
        
        local sp = cc.Sprite:create(""..i.."-"..i..".jpg")
        sp:setPosition(sp:getContentSize().width/2,sp:getContentSize().height/2)
        grid:addChild(sp)
        --[[
        local page = LuaUtils:uiLabel(grid,string.format("第%d页", i),cc.p(size.width/2,100),48)
        page:setColor(cc.c3b(0,0,0))
        ]]--

        local next = LuaUtils:uiLabel(grid,">>>",cc.p(size.width-100,size.height/2),96)
        next:setColor(cc.c3b(0,0,0))
        gridArray[i] = grid
    end
    
    --touch event
    local function onTouchBegan(touch, event)
        return true
    end
    local function onTouchEnd(touch, event)
        if begin then
            if girdIndex==10 then
                cc.SimpleAudioEngine:getInstance():playEffect("menu.wav")
                cc.Director:getInstance():replaceScene(FirstLayer:scene())
            elseif girdIndex<10 then
                gridArray[girdIndex]:runAction(cc.PageTurn3D:create(0.5, cc.size(10,6)))
            end
            girdIndex = girdIndex+1
        end
    end
    LuaUtils:touch(self,onTouchBegan,nil,onTouchEnd)

    cc.SimpleAudioEngine:getInstance():playMusic("main_theme.mp3",true)
end
