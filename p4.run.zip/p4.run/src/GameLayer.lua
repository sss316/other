cc.exports.GameLayer = class("GameLayer",function()
    return cc.Layer:create()
end)

function GameLayer:scene()
    local scene = cc.Scene:create()
    
    --   back
    local pngName = "back-"..UserInfo._colorName..".png"
    local size = cc.Sprite:create(pngName):getContentSize()
    size.width=size.width-1
    local function ActionSequenceCallback(back)
        back:runAction(cc.Sequence:create(
            cc.MoveTo:create((back:getPositionX()+size.width/2)/100,cc.p(-size.width/2,size.height/2)),
            cc.Place:create(cc.p(size.width*1.5-1,size.height/2)),
            cc.CallFunc:create(ActionSequenceCallback)
        ))
    end

    for i=1,2 do
        local back = cc.Sprite:create(pngName)
        back:setPosition(cc.p(size.width*(i-0.5),size.height/2))
        scene:addChild(back)
        ActionSequenceCallback(back)
    end

    cc.exports._GameLayer = GameLayer.new()
    scene:addChild(_GameLayer)

    cc.exports._UIBattleLayer = UIBattleLayer.new()
    scene:addChild(_UIBattleLayer)
    return scene
end

function GameLayer:ctor()
    self._player=nil
    self._roleArray={}
    self._rectArray={}
    self._boxArray={}

    local size = cc.Director:getInstance():getWinSize()

    local batchDecoration = cc.SpriteBatchNode:create("decoration_"..UserInfo._colorName..".pvr.ccz",400)
    self:addChild(batchDecoration)
    
    local batchNode = cc.SpriteBatchNode:create("feng.pvr.ccz",400)
    self:addChild(batchNode)
    --mi
    local ttfConfig = {}
    ttfConfig.fontFilePath = "fonts/Marker Felt.ttf"
    ttfConfig.fontSize = 20
    for i=1,30 do
        local mi = LuaUtils:uiLabel(self,tostring(100*i),cc.p(2000*i,size.height-100),96)
        mi:setColor(cc.c3b(168,208,222))
        
        local show = cc.Sprite:createWithSpriteFrameName("under.png")
        show:setPosition(cc.p(2000*i,size.height-240))
        show:setScale(3)
        batchNode:addChild(show)
        --[[
        line = cc.DrawNode:create()
        self:addChild(line)
        line:drawLine(cc.p(2000*i,size.height-300),cc.p(2000*i,size.height-150),cc.c4f(168/255,208/255,222/255,1))
        ]]--
    end

    --config
    local landData={}
    landData[1]={offW=0,height=100,width=3,tree=1,box=0}
    landData[2]={offW=300,height=100,width=1,tree=1,box=0}
    landData[3]={offW=300,height=120,width=1,tree=1,box=0}
    landData[4]={offW=400,height=150,width=1,tree=1,box=0}
    landData[5]={offW=400,height=110,width=1,tree=1,box=0}
    landData[6]={offW=400,height=200,width=2,tree=1,box=1}
    landData[7]={offW=400,height=300,width=3,tree=1,box=1}
    landData[8]={offW=800,height=400,width=3,tree=1,box=1}
    landData[9]={offW=500,height=100,width=1,tree=1,box=0}
    landData[10]={offW=500,height=100,width=1,tree=1,box=0}
    landData[11]={offW=500,height=100,width=1,tree=1,box=0}
    landData[12]={offW=800,height=150,width=1,tree=1,box=0}
    landData[13]={offW=600,height=100,width=1,tree=1,box=0}
    landData[14]={offW=600,height=100,width=1,tree=1,box=0}
    landData[15]={offW=800,height=300,width=2,tree=1,box=0}
    landData[16]={offW=500,height=400,width=3,tree=1,box=1}
    landData[17]={offW=600,height=200,width=1,tree=1,box=0}
    landData[18]={offW=600,height=100,width=1,tree=1,box=0}
    landData[19]={offW=500,height=120,width=1,tree=1,box=0}
    landData[20]={offW=600,height=150,width=1,tree=1,box=0}
    landData[21]={offW=600,height=110,width=1,tree=1,box=0}
    landData[22]={offW=700,height=300,width=2,tree=1,box=0}
    landData[23]={offW=800,height=400,width=3,tree=1,box=1}
    landData[24]={offW=700,height=400,width=3,tree=1,box=1}
    landData[25]={offW=800,height=100,width=2,tree=1,box=0}
    landData[26]={offW=300,height=100,width=1,tree=1,box=0}
    landData[27]={offW=800,height=100,width=1,tree=1,box=0}
    landData[28]={offW=700,height=150,width=1,tree=1,box=0}
    landData[29]={offW=800,height=300,width=1,tree=1,box=0}
    landData[30]={offW=900,height=400,width=3,tree=1,box=1}
    landData[31]={offW=900,height=200,width=1,tree=1,box=0}
    landData[32]={offW=800,height=200,width=1,tree=1,box=0}
    landData[33]={offW=800,height=400,width=1,tree=1,box=0}
    landData[34]={offW=1000,height=400,width=1,tree=1,box=0}
    landData[35]={offW=900,height=400,width=3,box=1}
    landData[36]={offW=1300,height=100,width=1,box=0}
    landData[37]={offW=900,height=350,width=1,box=0}
    landData[38]={offW=900,height=500,width=3,box=1}
    landData[39]={offW=1400,height=100,width=1,box=0}
    landData[40]={offW=900,height=350,width=1,box=0}
    landData[41]={offW=900,height=600,width=3,box=1}
    landData[42]={offW=1500,height=100,width=1,box=0}
    
    local lastW=0
    local landName = "land-"..UserInfo._colorName..".png"
    local landRect = cc.SpriteFrameCache:getInstance():getSpriteFrame(landName):getRect()
    landRect.width = landRect.width-1
    
    --black land need correct...
    if UserInfo._colorName=="black" then
        landRect.height = landRect.height-10
    end
    for i=1,#landData do
        lastW = lastW+landData[i].offW
        

        --decoration
        self:decoration(batchDecoration,landData[i].width,cc.rect(lastW,landData[i].height,landRect.width*landData[i].width,0))
        
        
        for j=1, landData[i].width do
            local left = cc.Sprite:createWithSpriteFrameName(landName)
            left:setAnchorPoint(0,0)
            left:setPosition(cc.p(lastW+landRect.width*(j-1),landData[i].height-landRect.height))
            batchNode:addChild(left)
        end
        
        --save to rect.
        local picW = landRect.width*landData[i].width
        self._rectArray[i]=cc.rect(lastW,0,picW,landData[i].height)
        
        --box
        if landData[i].box==1 then
            local boxSprite=cc.Sprite:createWithSpriteFrameName("box.png")
            local boxSize = boxSprite:getContentSize()
            boxSprite:setAnchorPoint(0,0)
            boxSprite:setPosition(lastW+picW/2-boxSize.width/2,landData[i].height)
            batchNode:addChild(boxSprite)
            table.insert(self._boxArray,cc.rect(lastW+picW/2-boxSize.width/2,landData[i].height,boxSize.width,boxSize.height))
        end
        lastW = lastW+picW
    end


    self:cloud(batchDecoration)

    LuaUtils:schedule(self,function(dt)
        for i,v in pairs(self._roleArray) do
            v._speed=v._speed+v._speedAdd
            local nextY = v:getNextY()
            --falling
            if self:inRect(v,cc.p(v:getPositionX()-v._offX,nextY))==false 
            and self:inRect(v,cc.p(v:getPositionX()+v._offX,nextY))==false then
                v:setPositionY(nextY)
                
                --Falling off a cliff
                if nextY<=0 then
                    v:dead()
                    break
                end
            else
                --touch land,you can jump.
                v._jumpNum=0
                v._moveY=0
            end     
            
            
            --right move,crash?
            if self:inRect(v,cc.p(v:getPositionX()+v._offX+v._speed,v:getPositionY()))==false then
                v:setPositionX(v:getPositionX()+v._speed)
            else
                v:dead()
                break
            end
            
        end
        
        --layer position
        if self._player then
            self:setPositionX(300-self._player:getPositionX())
            self._player:updateLine()
        end
    end,0.01)

    local function addRole()
        --create role
        for i=1, 5 do
            local role = Role.new()
            role:setPosition(cc.p(i*120,400))
            self:addChild(role)
            self._roleArray[#self._roleArray+1]=role
            if i==2 then self._player=role end
            role:initData(i)
        end
    end

    self:runAction(cc.Sequence:create(
        cc.DelayTime:create(0.1),
        cc.CallFunc:create(addRole)
    ))
    
    --To prevent shake
    self:setPositionX(60)
end

function GameLayer:inRect(role,point)
    if role._tileIndex<#self._rectArray 
    and role:getPositionX()+role._offX>=self._rectArray[role._tileIndex+1].x then
        role._tileIndex=role._tileIndex+1
    end
    if cc.rectContainsPoint(self._rectArray[role._tileIndex],point) then
        return true
    end

    --box collision
    if role._boxIndex<#self._boxArray 
        and role:getPositionX()+role._offX>=self._boxArray[role._boxIndex+1].x then
    	role._boxIndex=role._boxIndex+1
    end
    if cc.rectContainsPoint(self._boxArray[role._boxIndex],point) then
        return true
    end

    return false
end


function GameLayer:cloud(batchDecoration)
    local size = cc.Director:getInstance():getWinSize()
    size.width=size.width-1
    local deco={}
    if UserInfo._colorName=="black" then
        deco[1]={name="black-3.png",property=0.5,time=1}
        deco[2]={name="black-4.png",property=0.5,time=1}
        deco[3]={name="black-1.png",property=0.5,time=1}
        deco[4]={name="black-2.png",property=0.5,time=1}
    elseif  UserInfo._colorName=="blue" then
        deco[1]={name="blue-1.png",property=0.5,time=1}
    elseif  UserInfo._colorName=="green" then
        deco[1]={name="green-1.png",property=0.5,time=1}
    elseif  UserInfo._colorName=="red" then
        deco[1]={name="red-1.png",property=0.5,time=1}
        deco[2]={name="red-2.png",property=0.5,time=1}
    end


    local hillPosX = 0
    for k,v in pairs(deco) do
        local spriteW = cc.Sprite:createWithSpriteFrameName(v.name):getContentSize()
        spriteW.width=spriteW.width-1
        for i=1, 30 do
            local sprite = cc.Sprite:createWithSpriteFrameName(v.name)
            if v.name=="black-2.png" then
                sprite:setPosition(cc.p(spriteW.width*(i-0.5),360-350))
                sprite:setOpacity(255*0.2)
            elseif v.name=="black-1.png" then
                sprite:setPosition(cc.p(spriteW.width*(i-0.5),750-350))
            elseif v.name=="black-3.png" or v.name=="black-4.png" then
                hillPosX = hillPosX + spriteW.width*2
                sprite:setPosition(cc.p(hillPosX,spriteW.height))
                sprite:setScale(2)
            else
                sprite:setPosition(cc.p(spriteW.width*(i-0.5),size.height-spriteW.height/2))
            end
            batchDecoration:addChild(sprite)
        end
    end
end

function GameLayer:decoration(batchNode,landCount,rect)
    --on land
    local deco={}
    if UserInfo._colorName=="black" then
        deco[1]={name="black-7.png",property=0.2,time=1/landCount}
        deco[2]={name="black-8.png",property=0.3,time=2}
        deco[3]={name="black-9.png",property=0.7,time=3}
        deco[4]={name="black-10.png",property=0,time=1}
        deco[5]={name="black-11.png",property=1,time=1}
    elseif  UserInfo._colorName=="blue" then
        deco[1]={name="blue-6.png",property=0.2,time=1/landCount}
        deco[2]={name="blue-7.png",property=1,time=3}
        deco[3]={name="blue-8.png",property=0.5,time=1}
        deco[4]={name="blue-9.png",property=0.5,time=1}
        deco[5]={name="blue-10.png",property=1,time=1}
    elseif  UserInfo._colorName=="green" then
        deco[1]={name="green-3.png",property=0.5,time=1}
        deco[2]={name="green-4.png",property=0.5,time=1}
        deco[3]={name="green-5.png",property=0.5,time=1}
        deco[4]={name="green-6.png",property=0.5,time=1}
        deco[5]={name="green-7.png",property=0.5,time=1}
        deco[6]={name="green-8.png",property=0.5,time=1}
        deco[7]={name="green-9.png",property=0.5,time=1}
        deco[8]={name="green-10.png",property=1,time=1}
        deco[9]={name="green-11.png",property=0.5,time=1}
        deco[10]={name="green-12.png",property=0.5,time=1}
        deco[11]={name="green-13.png",property=0.5,time=1}
        deco[12]={name="green-14.png",property=0.5,time=1}
    elseif  UserInfo._colorName=="red" then
        deco[1]={name="red-4.png",property=1,time=3}
        deco[2]={name="red-5.png",property=1,time=2}
        deco[3]={name="red-6.png",property=1,time=1}
        deco[4]={name="red-7.png",property=1,time=2}
        deco[5]={name="red-8.png",property=1,time=1}
        deco[6]={name="red-9.png",property=1,time=2}
        deco[7]={name="red-10.png",property=0.5,time=1}
        deco[8]={name="red-11.png",property=0.5,time=1}
        deco[9]={name="red-12.png",property=0.5,time=1}
        deco[10]={name="red-13.png",property=0.5,time=1}
        deco[11]={name="red-14.png",property=1,time=1}
        deco[12]={name="red-15.png",property=1,time=1}
        deco[13]={name="red-16.png",property=1,time=1}
        deco[14]={name="red-17.png",property=1,time=1}
        deco[15]={name="red-18.png",property=1,time=1}
    end
    for k,v in pairs(deco) do
        for n=1, v.time*landCount do
    		if math.random()<v.property then
    			local sprite = cc.Sprite:createWithSpriteFrameName(v.name)
                sprite:setAnchorPoint(0,0)
                if v.name=="blue-10.png" or v.name=="red-18.png" or v.name=="black-11.png" or v.name=="green-10.png" then
                    sprite:setPosition(cc.p(rect.x+(n-1)*sprite:getContentSize().width,rect.y))
                else
                    sprite:setPosition(cc.p(rect.x+math.random()*(rect.width-sprite:getContentSize().width),rect.y))
                end
                if v.name=="black-7.png" or v.name=="blue-6.png" then
                    self:fruit(sprite)
                end
                if UserInfo._colorName=="black" then
                    batchNode:addChild(sprite,1)
                else
                    batchNode:addChild(sprite)
                end
    		end
    	end
    end
end

function GameLayer:fruit(tree)
    local points = {cc.p(70,391),cc.p(266,533),cc.p(520,451)}
    for k, v in pairs(points) do
        local scale = 1+math.random()
        local sprite = cc.Sprite:createWithSpriteFrameName(UserInfo._colorName=="black" and "black-10.png" or "blue-11.png")
        sprite:setPosition(v)
        sprite:setScale(scale)
        tree:addChild(sprite,1)
        sprite:runAction(cc.RepeatForever:create(cc.Sequence:create(cc.FadeOut:create(0.5+1*math.random()),cc.FadeIn:create(0.5+1*math.random()))))
        
        local particle = cc.ParticleSystemQuad:create("particles_fruit.plist")
        particle:setPosition(cc.pAdd(cc.p(tree:getPosition()),v))
        particle:setScale(scale)
        self:addChild(particle)
        particle:setPositionType(1)
    end
end

