cc.exports.Role = class("Role",function()return cc.Node:create()end)

function Role:initData(index)
    local back = cc.Sprite:createWithSpriteFrameName("r-1.png")
    back:setPosition(0,back:getContentSize().height/2)
    self:addChild(back)
    back:runAction(cc.RepeatForever:create(LuaUtils:animate("r-",4,0.07)))
    self._offX=back:getContentSize().width/2
    self._moveY=0
    self._jumpNum=0
    self._tileIndex=1
    self._boxIndex=1
    self._data={}
    self._dataIndex=1
    self._press=false
    self._speed=7
    self._speedAdd=0.01+index*0.002

    if self==_GameLayer._player then
        back:setColor(cc.c3b(255,0,255))
        UserInfo:addHat(self,back,UserInfo._selectedHero)
        
        --show you.
        self._showYou = ShowYou:create()
        _GameLayer:addChild(self._showYou)
    else
        local distance = cc.UserDefault:getInstance():getStringForKey("player"..(index==5 and 2 or index),"")
        self._data=LuaUtils:tableNum(LuaUtils:split(distance,","))
        local randNum = math.random(0,100)
        if randNum<=90 then randNum=1
        elseif randNum<=92 then randNum=2
        elseif randNum<=94 then randNum=3
        elseif randNum<=96 then randNum=4
        elseif randNum<=98 then randNum=5
        elseif randNum<=100 then randNum=6
        end
        UserInfo:addHat(self,back,randNum)
    end
    
--set ai
    LuaUtils:schedule(self,function(dt)
        --AI position jump
        if self~=_GameLayer._player then
            if self._dataIndex<=#self._data and self._data[self._dataIndex]<=self:getPositionX() then
                if self._dataIndex%2==1 then
                    self:touchBegin()
                else
                    self:touchEnd()
                end
                self._dataIndex=self._dataIndex+1
            end
        end
        if self._press then
            self._moveY=18
        end
    end,0)

end

function Role:updateLine()
    if self==_GameLayer._player then
        self._showYou:updatePos()
    end
end

function Role:getNextY()
    local temp = self._moveY
    self._moveY=temp-1.5
    return self:getPositionY()+temp
end

function Role:touchBegin()
    if self._jumpNum<2 then
        self._press=true
        self._jumpNum=self._jumpNum+1
        LuaUtils:tagAction(self,cc.Sequence:create(cc.DelayTime:create(0.2),cc.CallFunc:create(self.touchEnd)),
        UserInfo._TagJumpEnd)
    end
end

function Role:touchEnd()
    self._press=false
end

function Role:dead()
    cc.SimpleAudioEngine:getInstance():playEffect("lose.ogg")
    for k, v in pairs(_GameLayer._roleArray) do
        if v==self then
            table.remove(_GameLayer._roleArray,k)
            break
    	end
    end
    LuaUtils:tagAction(self,cc.RotateBy:create(0.3,-180),UserInfo._TagDead)
    
    
    if self==_GameLayer._player then
        print("gameover")
        UserInfo._curDistance = self:getPositionX()
        local distance = cc.UserDefault:getInstance():getStringForKey("distance","0,0,0,0")
        local t=LuaUtils:tableNum(LuaUtils:split(distance,","))
        local index = LuaUtils:tableMinkey(t)
        if t[index]<self:getPositionX() then
            t[index]=self:getPositionX()
            cc.UserDefault:getInstance():setStringForKey("distance",table.concat(t,","))
            cc.UserDefault:getInstance():setStringForKey("player"..index,table.concat(self._data,","))
            cc.UserDefault:getInstance():flush()
        end
        
        _GameLayer._player=nil
        local colors = {"red","green","black","blue"}
        if UserInfo._colorName=="red" then UserInfo._colorName = "green"
        elseif UserInfo._colorName=="green" then UserInfo._colorName = "black"
        elseif UserInfo._colorName=="black" then UserInfo._colorName = "blue"
        elseif UserInfo._colorName=="blue" then UserInfo._colorName = "red"
        else UserInfo._colorName = colors[math.random(1,4)] end
        _UIBattleLayer:addChild(WinLayer.new(),9)
--        self:runAction(cc.Sequence:create(cc.DelayTime:create(2),cc.CallFunc:create(go)))
    end
end


